import enum
from typing import List, Optional
from sqlalchemy import (
    create_engine, Column, ForeignKey, Table, Text, Boolean, String, Date, 
    Time, DateTime, Float, Integer, Enum
)
from sqlalchemy.orm import (
    column_property, DeclarativeBase, Mapped, mapped_column, relationship
)
from datetime import datetime as dt_datetime, time as dt_time, date as dt_date

class Base(DeclarativeBase):
    pass



# Tables definition for many-to-many relationships
reservation_prestation = Table(
    "reservation_prestation",
    Base.metadata,
    Column("prestation", ForeignKey("prestation.id"), primary_key=True),
    Column("reservation_2", ForeignKey("reservation.id"), primary_key=True),
)
reservation_materiel = Table(
    "reservation_materiel",
    Base.metadata,
    Column("materiel", ForeignKey("materiel.id"), primary_key=True),
    Column("reservation_1", ForeignKey("reservation.id"), primary_key=True),
)

# Tables definition
class Prestation(Base):
    __tablename__ = "prestation"
    id: Mapped[int] = mapped_column(primary_key=True)
    idPrestation: Mapped[int] = mapped_column(Integer)
    nom: Mapped[str] = mapped_column(String(100))
    type: Mapped[str] = mapped_column(String(100))
    capaciteMax: Mapped[int] = mapped_column(Integer)

class Materiel(Base):
    __tablename__ = "materiel"
    id: Mapped[int] = mapped_column(primary_key=True)
    idMateriel: Mapped[int] = mapped_column(Integer)
    nom: Mapped[str] = mapped_column(String(100))
    quantiteDisponible: Mapped[int] = mapped_column(Integer)

class Reservation(Base):
    __tablename__ = "reservation"
    id: Mapped[int] = mapped_column(primary_key=True)
    idReservation: Mapped[int] = mapped_column(Integer)
    dateDebut: Mapped[dt_date] = mapped_column(Date)
    dateFin: Mapped[dt_date] = mapped_column(Date)
    statut: Mapped[str] = mapped_column(String(100))
    montantTotal: Mapped[float] = mapped_column(Float)
    centre_1_id: Mapped[int] = mapped_column(ForeignKey("centre.id"))

class Indisponibilite(Base):
    __tablename__ = "indisponibilite"
    id: Mapped[int] = mapped_column(primary_key=True)
    idIndisponbilite: Mapped[int] = mapped_column(Integer)
    dateDebut: Mapped[dt_date] = mapped_column(Date)
    dateFin: Mapped[dt_date] = mapped_column(Date)
    raison: Mapped[str] = mapped_column(String(100))
    element_2_id: Mapped[int] = mapped_column(ForeignKey("element.id"))

class Tarif(Base):
    __tablename__ = "tarif"
    id: Mapped[int] = mapped_column(primary_key=True)
    idTarif: Mapped[int] = mapped_column(Integer)
    saison: Mapped[str] = mapped_column(String(100))
    prixParJour: Mapped[float] = mapped_column(Float)
    element_1_id: Mapped[int] = mapped_column(ForeignKey("element.id"))

class Element(Base):
    __tablename__ = "element"
    id: Mapped[int] = mapped_column(primary_key=True)
    idElement: Mapped[int] = mapped_column(Integer)
    nom: Mapped[str] = mapped_column(String(100))
    capaciteMax: Mapped[int] = mapped_column(Integer)
    dureeMinimale: Mapped[int] = mapped_column(Integer)
    jourInterdit: Mapped[str] = mapped_column(String(100))
    centre_id: Mapped[int] = mapped_column(ForeignKey("centre.id"), nullable=True)
    reservation_4_id: Mapped[int] = mapped_column(ForeignKey("reservation.id"), nullable=True)

class Evenement(Base):
    __tablename__ = "evenement"
    id: Mapped[int] = mapped_column(primary_key=True)
    idEvenement: Mapped[int] = mapped_column(Integer)
    nom: Mapped[str] = mapped_column(String(100))
    description: Mapped[str] = mapped_column(String(100))
    nbParticipants: Mapped[int] = mapped_column(Integer)
    emailReferent: Mapped[str] = mapped_column(String(100))
    reservation_id: Mapped[int] = mapped_column(ForeignKey("reservation.id"), nullable=True, unique=True)

class Centre(Base):
    __tablename__ = "centre"
    id: Mapped[int] = mapped_column(primary_key=True)
    adresse: Mapped[str] = mapped_column(String(100))
    idCentre: Mapped[int] = mapped_column(Integer)
    nom: Mapped[str] = mapped_column(String(100))


#--- Relationships of the prestation table
Prestation.reservation_2: Mapped[List["Reservation"]] = relationship("Reservation", secondary=reservation_prestation, back_populates="prestation")

#--- Relationships of the materiel table
Materiel.reservation_1: Mapped[List["Reservation"]] = relationship("Reservation", secondary=reservation_materiel, back_populates="materiel")

#--- Relationships of the reservation table
Reservation.centre_1: Mapped["Centre"] = relationship("Centre", back_populates="reservation_3", foreign_keys=[Reservation.centre_1_id])
Reservation.evenement: Mapped["Evenement"] = relationship("Evenement", back_populates="reservation", foreign_keys=[Evenement.reservation_id])
Reservation.materiel: Mapped[List["Materiel"]] = relationship("Materiel", secondary=reservation_materiel, back_populates="reservation_1")
Reservation.prestation: Mapped[List["Prestation"]] = relationship("Prestation", secondary=reservation_prestation, back_populates="reservation_2")
Reservation.element_3: Mapped[List["Element"]] = relationship("Element", back_populates="reservation_4", foreign_keys=[Element.reservation_4_id])

#--- Relationships of the indisponibilite table
Indisponibilite.element_2: Mapped["Element"] = relationship("Element", back_populates="indisponibilite", foreign_keys=[Indisponibilite.element_2_id])

#--- Relationships of the tarif table
Tarif.element_1: Mapped["Element"] = relationship("Element", back_populates="tarif", foreign_keys=[Tarif.element_1_id])

#--- Relationships of the element table
Element.centre: Mapped["Centre"] = relationship("Centre", back_populates="element", foreign_keys=[Element.centre_id])
Element.tarif: Mapped[List["Tarif"]] = relationship("Tarif", back_populates="element_1", foreign_keys=[Tarif.element_1_id])
Element.indisponibilite: Mapped[List["Indisponibilite"]] = relationship("Indisponibilite", back_populates="element_2", foreign_keys=[Indisponibilite.element_2_id])
Element.reservation_4: Mapped["Reservation"] = relationship("Reservation", back_populates="element_3", foreign_keys=[Element.reservation_4_id])

#--- Relationships of the evenement table
Evenement.reservation: Mapped["Reservation"] = relationship("Reservation", back_populates="evenement", foreign_keys=[Evenement.reservation_id])

#--- Relationships of the centre table
Centre.reservation_3: Mapped[List["Reservation"]] = relationship("Reservation", back_populates="centre_1", foreign_keys=[Reservation.centre_1_id])
Centre.element: Mapped[List["Element"]] = relationship("Element", back_populates="centre", foreign_keys=[Element.centre_id])

# Database connection
DATABASE_URL = "sqlite:///Class_Diagram.db"  # SQLite connection
engine = create_engine(DATABASE_URL, echo=True)

# Create tables in the database
Base.metadata.create_all(engine, checkfirst=True)