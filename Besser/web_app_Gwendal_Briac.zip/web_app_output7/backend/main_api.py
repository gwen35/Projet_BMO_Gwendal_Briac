import uvicorn
import os, json
import time as time_module
import logging
from fastapi import Depends, FastAPI, HTTPException, Request, status, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from pydantic_classes import *
from sql_alchemy import *

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

############################################
#
#   Initialize the database
#
############################################

def init_db():
    SQLALCHEMY_DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./data/Class_Diagram.db")
    # Ensure local SQLite directory exists (safe no-op for other DBs)
    os.makedirs("data", exist_ok=True)
    engine = create_engine(
        SQLALCHEMY_DATABASE_URL,
        connect_args={"check_same_thread": False},
        pool_size=10,
        max_overflow=20,
        pool_pre_ping=True,
        echo=False
    )
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    Base.metadata.create_all(bind=engine)
    return SessionLocal

app = FastAPI(
    title="Class_Diagram API",
    description="Auto-generated REST API with full CRUD operations, relationship management, and advanced features",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_tags=[
        {"name": "System", "description": "System health and statistics"},
        {"name": "Prestation", "description": "Operations for Prestation entities"},
        {"name": "Prestation Relationships", "description": "Manage Prestation relationships"},
        {"name": "Prestation Methods", "description": "Execute Prestation methods"},
        {"name": "Materiel", "description": "Operations for Materiel entities"},
        {"name": "Materiel Relationships", "description": "Manage Materiel relationships"},
        {"name": "Materiel Methods", "description": "Execute Materiel methods"},
        {"name": "Reservation", "description": "Operations for Reservation entities"},
        {"name": "Reservation Relationships", "description": "Manage Reservation relationships"},
        {"name": "Reservation Methods", "description": "Execute Reservation methods"},
        {"name": "Indisponibilite", "description": "Operations for Indisponibilite entities"},
        {"name": "Indisponibilite Relationships", "description": "Manage Indisponibilite relationships"},
        {"name": "Indisponibilite Methods", "description": "Execute Indisponibilite methods"},
        {"name": "Tarif", "description": "Operations for Tarif entities"},
        {"name": "Tarif Relationships", "description": "Manage Tarif relationships"},
        {"name": "Tarif Methods", "description": "Execute Tarif methods"},
        {"name": "Element", "description": "Operations for Element entities"},
        {"name": "Element Relationships", "description": "Manage Element relationships"},
        {"name": "Element Methods", "description": "Execute Element methods"},
        {"name": "Evenement", "description": "Operations for Evenement entities"},
        {"name": "Evenement Relationships", "description": "Manage Evenement relationships"},
        {"name": "Evenement Methods", "description": "Execute Evenement methods"},
        {"name": "Centre", "description": "Operations for Centre entities"},
        {"name": "Centre Relationships", "description": "Manage Centre relationships"},
        {"name": "Centre Methods", "description": "Execute Centre methods"},
    ]
)

# Enable CORS for all origins (for development)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Or restrict to ["http://localhost:3000"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

############################################
#
#   Middleware
#
############################################

# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log all incoming requests and responses."""
    logger.info(f"Incoming request: {request.method} {request.url.path}")
    response = await call_next(request)
    logger.info(f"Response status: {response.status_code}")
    return response

# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Add processing time header to all responses."""
    start_time = time_module.time()
    response = await call_next(request)
    process_time = time_module.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

############################################
#
#   Exception Handlers
#
############################################

# Global exception handlers
@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError):
    """Handle ValueError exceptions."""
    return JSONResponse(
        status_code=status.HTTP_400_BAD_REQUEST,
        content={
            "error": "Bad Request",
            "message": str(exc),
            "detail": "Invalid input data provided"
        }
    )


@app.exception_handler(IntegrityError)
async def integrity_error_handler(request: Request, exc: IntegrityError):
    """Handle database integrity errors."""
    logger.error(f"Database integrity error: {exc}")

    # Extract more detailed error information
    error_detail = str(exc.orig) if hasattr(exc, 'orig') else str(exc)

    return JSONResponse(
        status_code=status.HTTP_409_CONFLICT,
        content={
            "error": "Conflict",
            "message": "Data conflict occurred",
            "detail": error_detail
        }
    )


@app.exception_handler(SQLAlchemyError)
async def sqlalchemy_error_handler(request: Request, exc: SQLAlchemyError):
    """Handle general SQLAlchemy errors."""
    logger.error(f"Database error: {exc}")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "Internal Server Error",
            "message": "Database operation failed",
            "detail": "An internal database error occurred"
        }
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions with consistent format."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail if isinstance(exc.detail, str) else "HTTP Error",
            "message": exc.detail,
            "detail": f"HTTP {exc.status_code} error occurred"
        }
    )

# Initialize database session
SessionLocal = init_db()
# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    except Exception:
        db.rollback()
        logger.error("Database session rollback due to exception")
        raise
    finally:
        db.close()

############################################
#
#   Global API endpoints
#
############################################

@app.get("/", tags=["System"])
def root():
    """Root endpoint - API information"""
    return {
        "name": "Class_Diagram API",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health", tags=["System"])
def health_check():
    """Health check endpoint for monitoring"""
    from datetime import datetime
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "database": "connected"
    }


@app.get("/statistics", tags=["System"])
def get_statistics(database: Session = Depends(get_db)):
    """Get database statistics for all entities"""
    stats = {}
    stats["prestation_count"] = database.query(Prestation).count()
    stats["materiel_count"] = database.query(Materiel).count()
    stats["reservation_count"] = database.query(Reservation).count()
    stats["indisponibilite_count"] = database.query(Indisponibilite).count()
    stats["tarif_count"] = database.query(Tarif).count()
    stats["element_count"] = database.query(Element).count()
    stats["evenement_count"] = database.query(Evenement).count()
    stats["centre_count"] = database.query(Centre).count()
    stats["total_entities"] = sum(stats.values())
    return stats


############################################
#
#   BESSER Action Language standard lib
#
############################################


async def BAL_size(sequence:list) -> int:
    return len(sequence)

async def BAL_is_empty(sequence:list) -> bool:
    return len(sequence) == 0

async def BAL_add(sequence:list, elem) -> None:
    sequence.append(elem)

async def BAL_remove(sequence:list, elem) -> None:
    sequence.remove(elem)

async def BAL_contains(sequence:list, elem) -> bool:
    return elem in sequence

async def BAL_filter(sequence:list, predicate) -> list:
    return [elem for elem in sequence if predicate(elem)]

async def BAL_forall(sequence:list, predicate) -> bool:
    for elem in sequence:
        if not predicate(elem):
            return False
    return True

async def BAL_exists(sequence:list, predicate) -> bool:
    for elem in sequence:
        if predicate(elem):
            return True
    return False

async def BAL_one(sequence:list, predicate) -> bool:
    found = False
    for elem in sequence:
        if predicate(elem):
            if found:
                return False
            found = True
    return found

async def BAL_is_unique(sequence:list, mapping) -> bool:
    mapped = [mapping(elem) for elem in sequence]
    return len(set(mapped)) == len(mapped)

async def BAL_map(sequence:list, mapping) -> list:
    return [mapping(elem) for elem in sequence]

async def BAL_reduce(sequence:list, reduce_fn, aggregator) -> any:
    for elem in sequence:
        aggregator = reduce_fn(aggregator, elem)
    return aggregator


############################################
#
#   Prestation functions
#
############################################

@app.get("/prestation/", response_model=None, tags=["Prestation"])
def get_all_prestation(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Prestation)
        prestation_list = query.all()

        # Serialize with relationships included
        result = []
        for prestation_item in prestation_list:
            item_dict = prestation_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)

            # Add many-to-many and one-to-many relationship objects (full details)
            reservation_list = database.query(Reservation).join(reservation_prestation, Reservation.id == reservation_prestation.c.reservation_2).filter(reservation_prestation.c.prestation == prestation_item.id).all()
            item_dict['reservation_2'] = []
            for reservation_obj in reservation_list:
                reservation_dict = reservation_obj.__dict__.copy()
                reservation_dict.pop('_sa_instance_state', None)
                item_dict['reservation_2'].append(reservation_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Prestation).all()


@app.get("/prestation/count/", response_model=None, tags=["Prestation"])
def get_count_prestation(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Prestation entities"""
    count = database.query(Prestation).count()
    return {"count": count}


@app.get("/prestation/paginated/", response_model=None, tags=["Prestation"])
def get_paginated_prestation(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Prestation entities"""
    total = database.query(Prestation).count()
    prestation_list = database.query(Prestation).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": prestation_list
        }

    result = []
    for prestation_item in prestation_list:
        reservation_ids = database.query(reservation_prestation.c.reservation_2).filter(reservation_prestation.c.prestation == prestation_item.id).all()
        item_data = {
            "prestation": prestation_item,
            "reservation_ids": [x[0] for x in reservation_ids],
        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/prestation/search/", response_model=None, tags=["Prestation"])
def search_prestation(
    database: Session = Depends(get_db)
) -> list:
    """Search Prestation entities by attributes"""
    query = database.query(Prestation)


    results = query.all()
    return results


@app.get("/prestation/{prestation_id}/", response_model=None, tags=["Prestation"])
async def get_prestation(prestation_id: int, database: Session = Depends(get_db)) -> Prestation:
    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")

    reservation_ids = database.query(reservation_prestation.c.reservation_2).filter(reservation_prestation.c.prestation == db_prestation.id).all()
    response_data = {
        "prestation": db_prestation,
        "reservation_ids": [x[0] for x in reservation_ids],
}
    return response_data



@app.post("/prestation/", response_model=None, tags=["Prestation"])
async def create_prestation(prestation_data: PrestationCreate, database: Session = Depends(get_db)) -> Prestation:

    if prestation_data.reservation_2:
        for id in prestation_data.reservation_2:
            # Entity already validated before creation
            db_reservation = database.query(Reservation).filter(Reservation.id == id).first()
            if not db_reservation:
                raise HTTPException(status_code=404, detail=f"Reservation with ID {id} not found")

    db_prestation = Prestation(
        nom=prestation_data.nom,        type=prestation_data.type,        capaciteMax=prestation_data.capaciteMax,        idPrestation=prestation_data.idPrestation        )

    database.add(db_prestation)
    database.commit()
    database.refresh(db_prestation)


    if prestation_data.reservation_2:
        for id in prestation_data.reservation_2:
            # Entity already validated before creation
            db_reservation = database.query(Reservation).filter(Reservation.id == id).first()
            # Create the association
            association = reservation_prestation.insert().values(prestation=db_prestation.id, reservation_2=db_reservation.id)
            database.execute(association)
            database.commit()


    reservation_ids = database.query(reservation_prestation.c.reservation_2).filter(reservation_prestation.c.prestation == db_prestation.id).all()
    response_data = {
        "prestation": db_prestation,
        "reservation_ids": [x[0] for x in reservation_ids],
    }
    return response_data


@app.post("/prestation/bulk/", response_model=None, tags=["Prestation"])
async def bulk_create_prestation(items: list[PrestationCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Prestation entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_prestation = Prestation(
                nom=item_data.nom,                type=item_data.type,                capaciteMax=item_data.capaciteMax,                idPrestation=item_data.idPrestation            )
            database.add(db_prestation)
            database.flush()  # Get ID without committing
            created_items.append(db_prestation.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Prestation entities"
    }


@app.delete("/prestation/bulk/", response_model=None, tags=["Prestation"])
async def bulk_delete_prestation(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Prestation entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_prestation = database.query(Prestation).filter(Prestation.id == item_id).first()
        if db_prestation:
            database.delete(db_prestation)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Prestation entities"
    }

@app.put("/prestation/{prestation_id}/", response_model=None, tags=["Prestation"])
async def update_prestation(prestation_id: int, prestation_data: PrestationCreate, database: Session = Depends(get_db)) -> Prestation:
    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")

    setattr(db_prestation, 'nom', prestation_data.nom)
    setattr(db_prestation, 'type', prestation_data.type)
    setattr(db_prestation, 'capaciteMax', prestation_data.capaciteMax)
    setattr(db_prestation, 'idPrestation', prestation_data.idPrestation)
    existing_reservation_ids = [assoc.reservation_2 for assoc in database.execute(
        reservation_prestation.select().where(reservation_prestation.c.prestation == db_prestation.id))]

    reservations_to_remove = set(existing_reservation_ids) - set(prestation_data.reservation_2)
    for reservation_id in reservations_to_remove:
        association = reservation_prestation.delete().where(
            (reservation_prestation.c.prestation == db_prestation.id) & (reservation_prestation.c.reservation_2 == reservation_id))
        database.execute(association)

    new_reservation_ids = set(prestation_data.reservation_2) - set(existing_reservation_ids)
    for reservation_id in new_reservation_ids:
        db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
        if db_reservation is None:
            raise HTTPException(status_code=404, detail=f"Reservation with ID {reservation_id} not found")
        association = reservation_prestation.insert().values(reservation_2=db_reservation.id, prestation=db_prestation.id)
        database.execute(association)
    database.commit()
    database.refresh(db_prestation)

    reservation_ids = database.query(reservation_prestation.c.reservation_2).filter(reservation_prestation.c.prestation == db_prestation.id).all()
    response_data = {
        "prestation": db_prestation,
        "reservation_ids": [x[0] for x in reservation_ids],
    }
    return response_data


@app.delete("/prestation/{prestation_id}/", response_model=None, tags=["Prestation"])
async def delete_prestation(prestation_id: int, database: Session = Depends(get_db)):
    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")
    database.delete(db_prestation)
    database.commit()
    return db_prestation

@app.post("/prestation/{prestation_id}/reservation_2/{reservation_id}/", response_model=None, tags=["Prestation Relationships"])
async def add_reservation_2_to_prestation(prestation_id: int, reservation_id: int, database: Session = Depends(get_db)):
    """Add a Reservation to this Prestation's reservation_2 relationship"""
    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")

    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    # Check if relationship already exists
    existing = database.query(reservation_prestation).filter(
        (reservation_prestation.c.prestation == prestation_id) &
        (reservation_prestation.c.reservation_2 == reservation_id)
    ).first()

    if existing:
        raise HTTPException(status_code=400, detail="Relationship already exists")

    # Create the association
    association = reservation_prestation.insert().values(prestation=prestation_id, reservation_2=reservation_id)
    database.execute(association)
    database.commit()

    return {"message": "Reservation added to reservation_2 successfully"}


@app.delete("/prestation/{prestation_id}/reservation_2/{reservation_id}/", response_model=None, tags=["Prestation Relationships"])
async def remove_reservation_2_from_prestation(prestation_id: int, reservation_id: int, database: Session = Depends(get_db)):
    """Remove a Reservation from this Prestation's reservation_2 relationship"""
    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")

    # Check if relationship exists
    existing = database.query(reservation_prestation).filter(
        (reservation_prestation.c.prestation == prestation_id) &
        (reservation_prestation.c.reservation_2 == reservation_id)
    ).first()

    if not existing:
        raise HTTPException(status_code=404, detail="Relationship not found")

    # Delete the association
    association = reservation_prestation.delete().where(
        (reservation_prestation.c.prestation == prestation_id) &
        (reservation_prestation.c.reservation_2 == reservation_id)
    )
    database.execute(association)
    database.commit()

    return {"message": "Reservation removed from reservation_2 successfully"}


@app.get("/prestation/{prestation_id}/reservation_2/", response_model=None, tags=["Prestation Relationships"])
async def get_reservation_2_of_prestation(prestation_id: int, database: Session = Depends(get_db)):
    """Get all Reservation entities related to this Prestation through reservation_2"""
    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")

    reservation_ids = database.query(reservation_prestation.c.reservation_2).filter(reservation_prestation.c.prestation == prestation_id).all()
    reservation_list = database.query(Reservation).filter(Reservation.id.in_([id[0] for id in reservation_ids])).all()

    return {
        "prestation_id": prestation_id,
        "reservation_2_count": len(reservation_list),
        "reservation_2": reservation_list
    }



############################################
#   Prestation Method Endpoints
############################################




@app.post("/prestation/{prestation_id}/methods/__init__/", response_model=None, tags=["Prestation Methods"])
async def execute_prestation___init__(
    prestation_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the __init__ method on a Prestation instance.
    """
    # Retrieve the entity from the database
    _prestation_object = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if _prestation_object is None:
        raise HTTPException(status_code=404, detail="Prestation not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_prestation_object):
            _prestation_object.instances = []
            p1 = PrestationObj(1, "Conférence", "Culturel", 50)
            _prestation_object.instances.append(p1)

        class PrestationObj:
            def __init__(_prestation_object, idPrestation, nom, type, capaciteMax):
                _prestation_object.idPrestation = idPrestation
                _prestation_object.nom = nom
                _prestation_object.type = type
                _prestation_object.capaciteMax = capaciteMax

        result = await wrapper(_prestation_object)
        # Commit DB
        database.commit()
        database.refresh(_prestation_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "prestation_id": prestation_id,
            "method": "__init__",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")



############################################
#
#   Materiel functions
#
############################################

@app.get("/materiel/", response_model=None, tags=["Materiel"])
def get_all_materiel(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Materiel)
        materiel_list = query.all()

        # Serialize with relationships included
        result = []
        for materiel_item in materiel_list:
            item_dict = materiel_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)

            # Add many-to-many and one-to-many relationship objects (full details)
            reservation_list = database.query(Reservation).join(reservation_materiel, Reservation.id == reservation_materiel.c.reservation_1).filter(reservation_materiel.c.materiel == materiel_item.id).all()
            item_dict['reservation_1'] = []
            for reservation_obj in reservation_list:
                reservation_dict = reservation_obj.__dict__.copy()
                reservation_dict.pop('_sa_instance_state', None)
                item_dict['reservation_1'].append(reservation_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Materiel).all()


@app.get("/materiel/count/", response_model=None, tags=["Materiel"])
def get_count_materiel(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Materiel entities"""
    count = database.query(Materiel).count()
    return {"count": count}


@app.get("/materiel/paginated/", response_model=None, tags=["Materiel"])
def get_paginated_materiel(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Materiel entities"""
    total = database.query(Materiel).count()
    materiel_list = database.query(Materiel).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": materiel_list
        }

    result = []
    for materiel_item in materiel_list:
        reservation_ids = database.query(reservation_materiel.c.reservation_1).filter(reservation_materiel.c.materiel == materiel_item.id).all()
        item_data = {
            "materiel": materiel_item,
            "reservation_ids": [x[0] for x in reservation_ids],
        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/materiel/search/", response_model=None, tags=["Materiel"])
def search_materiel(
    database: Session = Depends(get_db)
) -> list:
    """Search Materiel entities by attributes"""
    query = database.query(Materiel)


    results = query.all()
    return results


@app.get("/materiel/{materiel_id}/", response_model=None, tags=["Materiel"])
async def get_materiel(materiel_id: int, database: Session = Depends(get_db)) -> Materiel:
    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")

    reservation_ids = database.query(reservation_materiel.c.reservation_1).filter(reservation_materiel.c.materiel == db_materiel.id).all()
    response_data = {
        "materiel": db_materiel,
        "reservation_ids": [x[0] for x in reservation_ids],
}
    return response_data



@app.post("/materiel/", response_model=None, tags=["Materiel"])
async def create_materiel(materiel_data: MaterielCreate, database: Session = Depends(get_db)) -> Materiel:

    if materiel_data.reservation_1:
        for id in materiel_data.reservation_1:
            # Entity already validated before creation
            db_reservation = database.query(Reservation).filter(Reservation.id == id).first()
            if not db_reservation:
                raise HTTPException(status_code=404, detail=f"Reservation with ID {id} not found")

    db_materiel = Materiel(
        quantiteDisponible=materiel_data.quantiteDisponible,        idMateriel=materiel_data.idMateriel,        nom=materiel_data.nom        )

    database.add(db_materiel)
    database.commit()
    database.refresh(db_materiel)


    if materiel_data.reservation_1:
        for id in materiel_data.reservation_1:
            # Entity already validated before creation
            db_reservation = database.query(Reservation).filter(Reservation.id == id).first()
            # Create the association
            association = reservation_materiel.insert().values(materiel=db_materiel.id, reservation_1=db_reservation.id)
            database.execute(association)
            database.commit()


    reservation_ids = database.query(reservation_materiel.c.reservation_1).filter(reservation_materiel.c.materiel == db_materiel.id).all()
    response_data = {
        "materiel": db_materiel,
        "reservation_ids": [x[0] for x in reservation_ids],
    }
    return response_data


@app.post("/materiel/bulk/", response_model=None, tags=["Materiel"])
async def bulk_create_materiel(items: list[MaterielCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Materiel entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_materiel = Materiel(
                quantiteDisponible=item_data.quantiteDisponible,                idMateriel=item_data.idMateriel,                nom=item_data.nom            )
            database.add(db_materiel)
            database.flush()  # Get ID without committing
            created_items.append(db_materiel.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Materiel entities"
    }


@app.delete("/materiel/bulk/", response_model=None, tags=["Materiel"])
async def bulk_delete_materiel(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Materiel entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_materiel = database.query(Materiel).filter(Materiel.id == item_id).first()
        if db_materiel:
            database.delete(db_materiel)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Materiel entities"
    }

@app.put("/materiel/{materiel_id}/", response_model=None, tags=["Materiel"])
async def update_materiel(materiel_id: int, materiel_data: MaterielCreate, database: Session = Depends(get_db)) -> Materiel:
    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")

    setattr(db_materiel, 'quantiteDisponible', materiel_data.quantiteDisponible)
    setattr(db_materiel, 'idMateriel', materiel_data.idMateriel)
    setattr(db_materiel, 'nom', materiel_data.nom)
    existing_reservation_ids = [assoc.reservation_1 for assoc in database.execute(
        reservation_materiel.select().where(reservation_materiel.c.materiel == db_materiel.id))]

    reservations_to_remove = set(existing_reservation_ids) - set(materiel_data.reservation_1)
    for reservation_id in reservations_to_remove:
        association = reservation_materiel.delete().where(
            (reservation_materiel.c.materiel == db_materiel.id) & (reservation_materiel.c.reservation_1 == reservation_id))
        database.execute(association)

    new_reservation_ids = set(materiel_data.reservation_1) - set(existing_reservation_ids)
    for reservation_id in new_reservation_ids:
        db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
        if db_reservation is None:
            raise HTTPException(status_code=404, detail=f"Reservation with ID {reservation_id} not found")
        association = reservation_materiel.insert().values(reservation_1=db_reservation.id, materiel=db_materiel.id)
        database.execute(association)
    database.commit()
    database.refresh(db_materiel)

    reservation_ids = database.query(reservation_materiel.c.reservation_1).filter(reservation_materiel.c.materiel == db_materiel.id).all()
    response_data = {
        "materiel": db_materiel,
        "reservation_ids": [x[0] for x in reservation_ids],
    }
    return response_data


@app.delete("/materiel/{materiel_id}/", response_model=None, tags=["Materiel"])
async def delete_materiel(materiel_id: int, database: Session = Depends(get_db)):
    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")
    database.delete(db_materiel)
    database.commit()
    return db_materiel

@app.post("/materiel/{materiel_id}/reservation_1/{reservation_id}/", response_model=None, tags=["Materiel Relationships"])
async def add_reservation_1_to_materiel(materiel_id: int, reservation_id: int, database: Session = Depends(get_db)):
    """Add a Reservation to this Materiel's reservation_1 relationship"""
    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")

    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    # Check if relationship already exists
    existing = database.query(reservation_materiel).filter(
        (reservation_materiel.c.materiel == materiel_id) &
        (reservation_materiel.c.reservation_1 == reservation_id)
    ).first()

    if existing:
        raise HTTPException(status_code=400, detail="Relationship already exists")

    # Create the association
    association = reservation_materiel.insert().values(materiel=materiel_id, reservation_1=reservation_id)
    database.execute(association)
    database.commit()

    return {"message": "Reservation added to reservation_1 successfully"}


@app.delete("/materiel/{materiel_id}/reservation_1/{reservation_id}/", response_model=None, tags=["Materiel Relationships"])
async def remove_reservation_1_from_materiel(materiel_id: int, reservation_id: int, database: Session = Depends(get_db)):
    """Remove a Reservation from this Materiel's reservation_1 relationship"""
    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")

    # Check if relationship exists
    existing = database.query(reservation_materiel).filter(
        (reservation_materiel.c.materiel == materiel_id) &
        (reservation_materiel.c.reservation_1 == reservation_id)
    ).first()

    if not existing:
        raise HTTPException(status_code=404, detail="Relationship not found")

    # Delete the association
    association = reservation_materiel.delete().where(
        (reservation_materiel.c.materiel == materiel_id) &
        (reservation_materiel.c.reservation_1 == reservation_id)
    )
    database.execute(association)
    database.commit()

    return {"message": "Reservation removed from reservation_1 successfully"}


@app.get("/materiel/{materiel_id}/reservation_1/", response_model=None, tags=["Materiel Relationships"])
async def get_reservation_1_of_materiel(materiel_id: int, database: Session = Depends(get_db)):
    """Get all Reservation entities related to this Materiel through reservation_1"""
    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")

    reservation_ids = database.query(reservation_materiel.c.reservation_1).filter(reservation_materiel.c.materiel == materiel_id).all()
    reservation_list = database.query(Reservation).filter(Reservation.id.in_([id[0] for id in reservation_ids])).all()

    return {
        "materiel_id": materiel_id,
        "reservation_1_count": len(reservation_list),
        "reservation_1": reservation_list
    }



############################################
#   Materiel Method Endpoints
############################################




@app.post("/materiel/{materiel_id}/methods/__init__/", response_model=None, tags=["Materiel Methods"])
async def execute_materiel___init__(
    materiel_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the __init__ method on a Materiel instance.
    """
    # Retrieve the entity from the database
    _materiel_object = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if _materiel_object is None:
        raise HTTPException(status_code=404, detail="Materiel not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_materiel_object):
            _materiel_object.instances = []
            m1 = MaterielObj(1, "Projecteur", 2)
            _materiel_object.instances.append(m1)

        class MaterielObj:
            def __init__(_materiel_object, idMateriel, nom, quantiteDisponible):
                _materiel_object.idMateriel = idMateriel
                _materiel_object.nom = nom
                _materiel_object.quantiteDisponible = quantiteDisponible


        result = await wrapper(_materiel_object)
        # Commit DB
        database.commit()
        database.refresh(_materiel_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "materiel_id": materiel_id,
            "method": "__init__",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")



############################################
#
#   Reservation functions
#
############################################

@app.get("/reservation/", response_model=None, tags=["Reservation"])
def get_all_reservation(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Reservation)
        query = query.options(joinedload(Reservation.evenement))
        query = query.options(joinedload(Reservation.centre_1))
        reservation_list = query.all()

        # Serialize with relationships included
        result = []
        for reservation_item in reservation_list:
            item_dict = reservation_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if reservation_item.evenement:
                related_obj = reservation_item.evenement
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['evenement'] = related_dict
            else:
                item_dict['evenement'] = None
            if reservation_item.centre_1:
                related_obj = reservation_item.centre_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['centre_1'] = related_dict
            else:
                item_dict['centre_1'] = None

            # Add many-to-many and one-to-many relationship objects (full details)
            prestation_list = database.query(Prestation).join(reservation_prestation, Prestation.id == reservation_prestation.c.prestation).filter(reservation_prestation.c.reservation_2 == reservation_item.id).all()
            item_dict['prestation'] = []
            for prestation_obj in prestation_list:
                prestation_dict = prestation_obj.__dict__.copy()
                prestation_dict.pop('_sa_instance_state', None)
                item_dict['prestation'].append(prestation_dict)
            materiel_list = database.query(Materiel).join(reservation_materiel, Materiel.id == reservation_materiel.c.materiel).filter(reservation_materiel.c.reservation_1 == reservation_item.id).all()
            item_dict['materiel'] = []
            for materiel_obj in materiel_list:
                materiel_dict = materiel_obj.__dict__.copy()
                materiel_dict.pop('_sa_instance_state', None)
                item_dict['materiel'].append(materiel_dict)
            element_list = database.query(Element).filter(Element.reservation_4_id == reservation_item.id).all()
            item_dict['element_3'] = []
            for element_obj in element_list:
                element_dict = element_obj.__dict__.copy()
                element_dict.pop('_sa_instance_state', None)
                item_dict['element_3'].append(element_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Reservation).all()


@app.get("/reservation/count/", response_model=None, tags=["Reservation"])
def get_count_reservation(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Reservation entities"""
    count = database.query(Reservation).count()
    return {"count": count}


@app.get("/reservation/paginated/", response_model=None, tags=["Reservation"])
def get_paginated_reservation(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Reservation entities"""
    total = database.query(Reservation).count()
    reservation_list = database.query(Reservation).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": reservation_list
        }

    result = []
    for reservation_item in reservation_list:
        prestation_ids = database.query(reservation_prestation.c.prestation).filter(reservation_prestation.c.reservation_2 == reservation_item.id).all()
        materiel_ids = database.query(reservation_materiel.c.materiel).filter(reservation_materiel.c.reservation_1 == reservation_item.id).all()
        element_3_ids = database.query(Element.id).filter(Element.reservation_4_id == reservation_item.id).all()
        item_data = {
            "reservation": reservation_item,
            "prestation_ids": [x[0] for x in prestation_ids],
            "materiel_ids": [x[0] for x in materiel_ids],
            "element_3_ids": [x[0] for x in element_3_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/reservation/search/", response_model=None, tags=["Reservation"])
def search_reservation(
    database: Session = Depends(get_db)
) -> list:
    """Search Reservation entities by attributes"""
    query = database.query(Reservation)


    results = query.all()
    return results


@app.get("/reservation/{reservation_id}/", response_model=None, tags=["Reservation"])
async def get_reservation(reservation_id: int, database: Session = Depends(get_db)) -> Reservation:
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    prestation_ids = database.query(reservation_prestation.c.prestation).filter(reservation_prestation.c.reservation_2 == db_reservation.id).all()
    materiel_ids = database.query(reservation_materiel.c.materiel).filter(reservation_materiel.c.reservation_1 == db_reservation.id).all()
    element_3_ids = database.query(Element.id).filter(Element.reservation_4_id == db_reservation.id).all()
    response_data = {
        "reservation": db_reservation,
        "prestation_ids": [x[0] for x in prestation_ids],
        "materiel_ids": [x[0] for x in materiel_ids],
        "element_3_ids": [x[0] for x in element_3_ids]}
    return response_data



@app.post("/reservation/", response_model=None, tags=["Reservation"])
async def create_reservation(reservation_data: ReservationCreate, database: Session = Depends(get_db)) -> Reservation:

    if reservation_data.centre_1 is not None:
        db_centre_1 = database.query(Centre).filter(Centre.id == reservation_data.centre_1).first()
        if not db_centre_1:
            raise HTTPException(status_code=400, detail="Centre not found")
    else:
        raise HTTPException(status_code=400, detail="Centre ID is required")
    if reservation_data.prestation:
        for id in reservation_data.prestation:
            # Entity already validated before creation
            db_prestation = database.query(Prestation).filter(Prestation.id == id).first()
            if not db_prestation:
                raise HTTPException(status_code=404, detail=f"Prestation with ID {id} not found")
    if reservation_data.materiel:
        for id in reservation_data.materiel:
            # Entity already validated before creation
            db_materiel = database.query(Materiel).filter(Materiel.id == id).first()
            if not db_materiel:
                raise HTTPException(status_code=404, detail=f"Materiel with ID {id} not found")

    db_reservation = Reservation(
        dateDebut=reservation_data.dateDebut,        montantTotal=reservation_data.montantTotal,        idReservation=reservation_data.idReservation,        statut=reservation_data.statut,        dateFin=reservation_data.dateFin,        centre_1_id=reservation_data.centre_1        )

    database.add(db_reservation)
    database.commit()
    database.refresh(db_reservation)

    if reservation_data.element_3:
        # Validate that all Element IDs exist
        for element_id in reservation_data.element_3:
            db_element = database.query(Element).filter(Element.id == element_id).first()
            if not db_element:
                raise HTTPException(status_code=400, detail=f"Element with id {element_id} not found")

        # Update the related entities with the new foreign key
        database.query(Element).filter(Element.id.in_(reservation_data.element_3)).update(
            {Element.reservation_4_id: db_reservation.id}, synchronize_session=False
        )
        database.commit()

    if reservation_data.prestation:
        for id in reservation_data.prestation:
            # Entity already validated before creation
            db_prestation = database.query(Prestation).filter(Prestation.id == id).first()
            # Create the association
            association = reservation_prestation.insert().values(reservation_2=db_reservation.id, prestation=db_prestation.id)
            database.execute(association)
            database.commit()
    if reservation_data.materiel:
        for id in reservation_data.materiel:
            # Entity already validated before creation
            db_materiel = database.query(Materiel).filter(Materiel.id == id).first()
            # Create the association
            association = reservation_materiel.insert().values(reservation_1=db_reservation.id, materiel=db_materiel.id)
            database.execute(association)
            database.commit()


    prestation_ids = database.query(reservation_prestation.c.prestation).filter(reservation_prestation.c.reservation_2 == db_reservation.id).all()
    materiel_ids = database.query(reservation_materiel.c.materiel).filter(reservation_materiel.c.reservation_1 == db_reservation.id).all()
    element_3_ids = database.query(Element.id).filter(Element.reservation_4_id == db_reservation.id).all()
    response_data = {
        "reservation": db_reservation,
        "prestation_ids": [x[0] for x in prestation_ids],
        "materiel_ids": [x[0] for x in materiel_ids],
        "element_3_ids": [x[0] for x in element_3_ids]    }
    return response_data


@app.post("/reservation/bulk/", response_model=None, tags=["Reservation"])
async def bulk_create_reservation(items: list[ReservationCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Reservation entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.centre_1:
                raise ValueError("Centre ID is required")

            db_reservation = Reservation(
                dateDebut=item_data.dateDebut,                montantTotal=item_data.montantTotal,                idReservation=item_data.idReservation,                statut=item_data.statut,                dateFin=item_data.dateFin,                centre_1_id=item_data.centre_1            )
            database.add(db_reservation)
            database.flush()  # Get ID without committing
            created_items.append(db_reservation.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Reservation entities"
    }


@app.delete("/reservation/bulk/", response_model=None, tags=["Reservation"])
async def bulk_delete_reservation(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Reservation entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_reservation = database.query(Reservation).filter(Reservation.id == item_id).first()
        if db_reservation:
            database.delete(db_reservation)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Reservation entities"
    }

@app.put("/reservation/{reservation_id}/", response_model=None, tags=["Reservation"])
async def update_reservation(reservation_id: int, reservation_data: ReservationCreate, database: Session = Depends(get_db)) -> Reservation:
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    setattr(db_reservation, 'dateDebut', reservation_data.dateDebut)
    setattr(db_reservation, 'montantTotal', reservation_data.montantTotal)
    setattr(db_reservation, 'idReservation', reservation_data.idReservation)
    setattr(db_reservation, 'statut', reservation_data.statut)
    setattr(db_reservation, 'dateFin', reservation_data.dateFin)
    if reservation_data.centre_1 is not None:
        db_centre_1 = database.query(Centre).filter(Centre.id == reservation_data.centre_1).first()
        if not db_centre_1:
            raise HTTPException(status_code=400, detail="Centre not found")
        setattr(db_reservation, 'centre_1_id', reservation_data.centre_1)
    if reservation_data.element_3 is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Element).filter(Element.reservation_4_id == db_reservation.id).update(
            {Element.reservation_4_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if reservation_data.element_3:
            # Validate that all IDs exist
            for element_id in reservation_data.element_3:
                db_element = database.query(Element).filter(Element.id == element_id).first()
                if not db_element:
                    raise HTTPException(status_code=400, detail=f"Element with id {element_id} not found")

            # Update the related entities with the new foreign key
            database.query(Element).filter(Element.id.in_(reservation_data.element_3)).update(
                {Element.reservation_4_id: db_reservation.id}, synchronize_session=False
            )
    existing_prestation_ids = [assoc.prestation for assoc in database.execute(
        reservation_prestation.select().where(reservation_prestation.c.reservation_2 == db_reservation.id))]

    prestations_to_remove = set(existing_prestation_ids) - set(reservation_data.prestation)
    for prestation_id in prestations_to_remove:
        association = reservation_prestation.delete().where(
            (reservation_prestation.c.reservation_2 == db_reservation.id) & (reservation_prestation.c.prestation == prestation_id))
        database.execute(association)

    new_prestation_ids = set(reservation_data.prestation) - set(existing_prestation_ids)
    for prestation_id in new_prestation_ids:
        db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
        if db_prestation is None:
            raise HTTPException(status_code=404, detail=f"Prestation with ID {prestation_id} not found")
        association = reservation_prestation.insert().values(prestation=db_prestation.id, reservation_2=db_reservation.id)
        database.execute(association)
    existing_materiel_ids = [assoc.materiel for assoc in database.execute(
        reservation_materiel.select().where(reservation_materiel.c.reservation_1 == db_reservation.id))]

    materiels_to_remove = set(existing_materiel_ids) - set(reservation_data.materiel)
    for materiel_id in materiels_to_remove:
        association = reservation_materiel.delete().where(
            (reservation_materiel.c.reservation_1 == db_reservation.id) & (reservation_materiel.c.materiel == materiel_id))
        database.execute(association)

    new_materiel_ids = set(reservation_data.materiel) - set(existing_materiel_ids)
    for materiel_id in new_materiel_ids:
        db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
        if db_materiel is None:
            raise HTTPException(status_code=404, detail=f"Materiel with ID {materiel_id} not found")
        association = reservation_materiel.insert().values(materiel=db_materiel.id, reservation_1=db_reservation.id)
        database.execute(association)
    database.commit()
    database.refresh(db_reservation)

    prestation_ids = database.query(reservation_prestation.c.prestation).filter(reservation_prestation.c.reservation_2 == db_reservation.id).all()
    materiel_ids = database.query(reservation_materiel.c.materiel).filter(reservation_materiel.c.reservation_1 == db_reservation.id).all()
    element_3_ids = database.query(Element.id).filter(Element.reservation_4_id == db_reservation.id).all()
    response_data = {
        "reservation": db_reservation,
        "prestation_ids": [x[0] for x in prestation_ids],
        "materiel_ids": [x[0] for x in materiel_ids],
        "element_3_ids": [x[0] for x in element_3_ids]    }
    return response_data


@app.delete("/reservation/{reservation_id}/", response_model=None, tags=["Reservation"])
async def delete_reservation(reservation_id: int, database: Session = Depends(get_db)):
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")
    database.delete(db_reservation)
    database.commit()
    return db_reservation

@app.post("/reservation/{reservation_id}/prestation/{prestation_id}/", response_model=None, tags=["Reservation Relationships"])
async def add_prestation_to_reservation(reservation_id: int, prestation_id: int, database: Session = Depends(get_db)):
    """Add a Prestation to this Reservation's prestation relationship"""
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    db_prestation = database.query(Prestation).filter(Prestation.id == prestation_id).first()
    if db_prestation is None:
        raise HTTPException(status_code=404, detail="Prestation not found")

    # Check if relationship already exists
    existing = database.query(reservation_prestation).filter(
        (reservation_prestation.c.reservation_2 == reservation_id) &
        (reservation_prestation.c.prestation == prestation_id)
    ).first()

    if existing:
        raise HTTPException(status_code=400, detail="Relationship already exists")

    # Create the association
    association = reservation_prestation.insert().values(reservation_2=reservation_id, prestation=prestation_id)
    database.execute(association)
    database.commit()

    return {"message": "Prestation added to prestation successfully"}


@app.delete("/reservation/{reservation_id}/prestation/{prestation_id}/", response_model=None, tags=["Reservation Relationships"])
async def remove_prestation_from_reservation(reservation_id: int, prestation_id: int, database: Session = Depends(get_db)):
    """Remove a Prestation from this Reservation's prestation relationship"""
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    # Check if relationship exists
    existing = database.query(reservation_prestation).filter(
        (reservation_prestation.c.reservation_2 == reservation_id) &
        (reservation_prestation.c.prestation == prestation_id)
    ).first()

    if not existing:
        raise HTTPException(status_code=404, detail="Relationship not found")

    # Delete the association
    association = reservation_prestation.delete().where(
        (reservation_prestation.c.reservation_2 == reservation_id) &
        (reservation_prestation.c.prestation == prestation_id)
    )
    database.execute(association)
    database.commit()

    return {"message": "Prestation removed from prestation successfully"}


@app.get("/reservation/{reservation_id}/prestation/", response_model=None, tags=["Reservation Relationships"])
async def get_prestation_of_reservation(reservation_id: int, database: Session = Depends(get_db)):
    """Get all Prestation entities related to this Reservation through prestation"""
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    prestation_ids = database.query(reservation_prestation.c.prestation).filter(reservation_prestation.c.reservation_2 == reservation_id).all()
    prestation_list = database.query(Prestation).filter(Prestation.id.in_([id[0] for id in prestation_ids])).all()

    return {
        "reservation_id": reservation_id,
        "prestation_count": len(prestation_list),
        "prestation": prestation_list
    }

@app.post("/reservation/{reservation_id}/materiel/{materiel_id}/", response_model=None, tags=["Reservation Relationships"])
async def add_materiel_to_reservation(reservation_id: int, materiel_id: int, database: Session = Depends(get_db)):
    """Add a Materiel to this Reservation's materiel relationship"""
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    db_materiel = database.query(Materiel).filter(Materiel.id == materiel_id).first()
    if db_materiel is None:
        raise HTTPException(status_code=404, detail="Materiel not found")

    # Check if relationship already exists
    existing = database.query(reservation_materiel).filter(
        (reservation_materiel.c.reservation_1 == reservation_id) &
        (reservation_materiel.c.materiel == materiel_id)
    ).first()

    if existing:
        raise HTTPException(status_code=400, detail="Relationship already exists")

    # Create the association
    association = reservation_materiel.insert().values(reservation_1=reservation_id, materiel=materiel_id)
    database.execute(association)
    database.commit()

    return {"message": "Materiel added to materiel successfully"}


@app.delete("/reservation/{reservation_id}/materiel/{materiel_id}/", response_model=None, tags=["Reservation Relationships"])
async def remove_materiel_from_reservation(reservation_id: int, materiel_id: int, database: Session = Depends(get_db)):
    """Remove a Materiel from this Reservation's materiel relationship"""
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    # Check if relationship exists
    existing = database.query(reservation_materiel).filter(
        (reservation_materiel.c.reservation_1 == reservation_id) &
        (reservation_materiel.c.materiel == materiel_id)
    ).first()

    if not existing:
        raise HTTPException(status_code=404, detail="Relationship not found")

    # Delete the association
    association = reservation_materiel.delete().where(
        (reservation_materiel.c.reservation_1 == reservation_id) &
        (reservation_materiel.c.materiel == materiel_id)
    )
    database.execute(association)
    database.commit()

    return {"message": "Materiel removed from materiel successfully"}


@app.get("/reservation/{reservation_id}/materiel/", response_model=None, tags=["Reservation Relationships"])
async def get_materiel_of_reservation(reservation_id: int, database: Session = Depends(get_db)):
    """Get all Materiel entities related to this Reservation through materiel"""
    db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if db_reservation is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    materiel_ids = database.query(reservation_materiel.c.materiel).filter(reservation_materiel.c.reservation_1 == reservation_id).all()
    materiel_list = database.query(Materiel).filter(Materiel.id.in_([id[0] for id in materiel_ids])).all()

    return {
        "reservation_id": reservation_id,
        "materiel_count": len(materiel_list),
        "materiel": materiel_list
    }



############################################
#   Reservation Method Endpoints
############################################




@app.post("/reservation/{reservation_id}/methods/confirmer/", response_model=None, tags=["Reservation Methods"])
async def execute_reservation_confirmer(
    reservation_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the confirmer method on a Reservation instance.
    """
    # Retrieve the entity from the database
    _reservation_object = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if _reservation_object is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_reservation_object):
            _reservation_object.calculer_montant_total()
            print(f"Paiement reçu pour la réservation {_reservation_object.id_reservation}")
            return True

        result = await wrapper(_reservation_object)
        # Commit DB
        database.commit()
        database.refresh(_reservation_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "reservation_id": reservation_id,
            "method": "confirmer",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")





@app.post("/reservation/{reservation_id}/methods/terminer/", response_model=None, tags=["Reservation Methods"])
async def execute_reservation_terminer(
    reservation_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the terminer method on a Reservation instance.
    """
    # Retrieve the entity from the database
    _reservation_object = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if _reservation_object is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_reservation_object):
            from datetime import date
            if date.today() > _reservation_object.dateFin:
                return True
            return False

        result = await wrapper(_reservation_object)
        # Commit DB
        database.commit()
        database.refresh(_reservation_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "reservation_id": reservation_id,
            "method": "terminer",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")





@app.post("/reservation/{reservation_id}/methods/annuler/", response_model=None, tags=["Reservation Methods"])
async def execute_reservation_annuler(
    reservation_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the annuler method on a Reservation instance.
    """
    # Retrieve the entity from the database
    _reservation_object = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if _reservation_object is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_reservation_object):
                from datetime import date
                if date.today() < _reservation_object.dateDebut:
                    print(f"Réservation {_reservation_object.id_reservation} annulée.")
                    return True
                else:
                    print("Impossible d'annuler : l'événement a déjà commencé ou est passé.")
                    return False

        result = await wrapper(_reservation_object)
        # Commit DB
        database.commit()
        database.refresh(_reservation_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "reservation_id": reservation_id,
            "method": "annuler",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")





@app.post("/reservation/{reservation_id}/methods/est_modifiable/", response_model=None, tags=["Reservation Methods"])
async def execute_reservation_est_modifiable(
    reservation_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the est_modifiable method on a Reservation instance.
    """
    # Retrieve the entity from the database
    _reservation_object = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if _reservation_object is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_reservation_object):
            from datetime import date
            return date.today() < _reservation_object.dateDebut

        result = await wrapper(_reservation_object)
        # Commit DB
        database.commit()
        database.refresh(_reservation_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "reservation_id": reservation_id,
            "method": "est_modifiable",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")





@app.post("/reservation/{reservation_id}/methods/__init__/", response_model=None, tags=["Reservation Methods"])
async def execute_reservation___init__(
    reservation_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the __init__ method on a Reservation instance.
    """
    # Retrieve the entity from the database
    _reservation_object = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if _reservation_object is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_reservation_object):
            _reservation_object.instances = []
            r1 = ReservationObj(1, "2026-03-01", "2026-03-02", "VALIDEE", 150.0)
            _reservation_object.instances.append(r1)

        class ReservationObj:
            def __init__(_reservation_object, idReservation, dateDebut, dateFin, statut, montantTotal):
                _reservation_object.idReservation = idReservation
                _reservation_object.dateDebut = dateDebut
                _reservation_object.dateFin = dateFin
                _reservation_object.statut = statut
                _reservation_object.montantTotal = montantTotal

        result = await wrapper(_reservation_object)
        # Commit DB
        database.commit()
        database.refresh(_reservation_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "reservation_id": reservation_id,
            "method": "__init__",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")





@app.post("/reservation/{reservation_id}/methods/calculer_montant_total/", response_model=None, tags=["Reservation Methods"])
async def execute_reservation_calculer_montant_total(
    reservation_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the calculer_montant_total method on a Reservation instance.
    """
    # Retrieve the entity from the database
    _reservation_object = database.query(Reservation).filter(Reservation.id == reservation_id).first()
    if _reservation_object is None:
        raise HTTPException(status_code=404, detail="Reservation not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_reservation_object):
            delta = _reservation_object.dateFin - _reservation_object.dateDebut
            nb_jours = max(delta.days, 1)

            total = 0
            if _reservation_object.element and _reservation_object.element.tarifs:
                total += _reservation_object.element.tarifs[0].prixParJour * nb_jours

            for m in _reservation_object.materiels:
                total += 50

            _reservation_object.montantTotal = total
            return total																	

        result = await wrapper(_reservation_object)
        # Commit DB
        database.commit()
        database.refresh(_reservation_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "reservation_id": reservation_id,
            "method": "calculer_montant_total",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")



############################################
#
#   Indisponibilite functions
#
############################################

@app.get("/indisponibilite/", response_model=None, tags=["Indisponibilite"])
def get_all_indisponibilite(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Indisponibilite)
        query = query.options(joinedload(Indisponibilite.element_2))
        indisponibilite_list = query.all()

        # Serialize with relationships included
        result = []
        for indisponibilite_item in indisponibilite_list:
            item_dict = indisponibilite_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if indisponibilite_item.element_2:
                related_obj = indisponibilite_item.element_2
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['element_2'] = related_dict
            else:
                item_dict['element_2'] = None


            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Indisponibilite).all()


@app.get("/indisponibilite/count/", response_model=None, tags=["Indisponibilite"])
def get_count_indisponibilite(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Indisponibilite entities"""
    count = database.query(Indisponibilite).count()
    return {"count": count}


@app.get("/indisponibilite/paginated/", response_model=None, tags=["Indisponibilite"])
def get_paginated_indisponibilite(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Indisponibilite entities"""
    total = database.query(Indisponibilite).count()
    indisponibilite_list = database.query(Indisponibilite).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": indisponibilite_list
    }


@app.get("/indisponibilite/search/", response_model=None, tags=["Indisponibilite"])
def search_indisponibilite(
    database: Session = Depends(get_db)
) -> list:
    """Search Indisponibilite entities by attributes"""
    query = database.query(Indisponibilite)


    results = query.all()
    return results


@app.get("/indisponibilite/{indisponibilite_id}/", response_model=None, tags=["Indisponibilite"])
async def get_indisponibilite(indisponibilite_id: int, database: Session = Depends(get_db)) -> Indisponibilite:
    db_indisponibilite = database.query(Indisponibilite).filter(Indisponibilite.id == indisponibilite_id).first()
    if db_indisponibilite is None:
        raise HTTPException(status_code=404, detail="Indisponibilite not found")

    response_data = {
        "indisponibilite": db_indisponibilite,
}
    return response_data



@app.post("/indisponibilite/", response_model=None, tags=["Indisponibilite"])
async def create_indisponibilite(indisponibilite_data: IndisponibiliteCreate, database: Session = Depends(get_db)) -> Indisponibilite:

    if indisponibilite_data.element_2 is not None:
        db_element_2 = database.query(Element).filter(Element.id == indisponibilite_data.element_2).first()
        if not db_element_2:
            raise HTTPException(status_code=400, detail="Element not found")
    else:
        raise HTTPException(status_code=400, detail="Element ID is required")

    db_indisponibilite = Indisponibilite(
        idIndisponbilite=indisponibilite_data.idIndisponbilite,        raison=indisponibilite_data.raison,        dateFin=indisponibilite_data.dateFin,        dateDebut=indisponibilite_data.dateDebut,        element_2_id=indisponibilite_data.element_2        )

    database.add(db_indisponibilite)
    database.commit()
    database.refresh(db_indisponibilite)




    return db_indisponibilite


@app.post("/indisponibilite/bulk/", response_model=None, tags=["Indisponibilite"])
async def bulk_create_indisponibilite(items: list[IndisponibiliteCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Indisponibilite entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.element_2:
                raise ValueError("Element ID is required")

            db_indisponibilite = Indisponibilite(
                idIndisponbilite=item_data.idIndisponbilite,                raison=item_data.raison,                dateFin=item_data.dateFin,                dateDebut=item_data.dateDebut,                element_2_id=item_data.element_2            )
            database.add(db_indisponibilite)
            database.flush()  # Get ID without committing
            created_items.append(db_indisponibilite.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Indisponibilite entities"
    }


@app.delete("/indisponibilite/bulk/", response_model=None, tags=["Indisponibilite"])
async def bulk_delete_indisponibilite(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Indisponibilite entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_indisponibilite = database.query(Indisponibilite).filter(Indisponibilite.id == item_id).first()
        if db_indisponibilite:
            database.delete(db_indisponibilite)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Indisponibilite entities"
    }

@app.put("/indisponibilite/{indisponibilite_id}/", response_model=None, tags=["Indisponibilite"])
async def update_indisponibilite(indisponibilite_id: int, indisponibilite_data: IndisponibiliteCreate, database: Session = Depends(get_db)) -> Indisponibilite:
    db_indisponibilite = database.query(Indisponibilite).filter(Indisponibilite.id == indisponibilite_id).first()
    if db_indisponibilite is None:
        raise HTTPException(status_code=404, detail="Indisponibilite not found")

    setattr(db_indisponibilite, 'idIndisponbilite', indisponibilite_data.idIndisponbilite)
    setattr(db_indisponibilite, 'raison', indisponibilite_data.raison)
    setattr(db_indisponibilite, 'dateFin', indisponibilite_data.dateFin)
    setattr(db_indisponibilite, 'dateDebut', indisponibilite_data.dateDebut)
    if indisponibilite_data.element_2 is not None:
        db_element_2 = database.query(Element).filter(Element.id == indisponibilite_data.element_2).first()
        if not db_element_2:
            raise HTTPException(status_code=400, detail="Element not found")
        setattr(db_indisponibilite, 'element_2_id', indisponibilite_data.element_2)
    database.commit()
    database.refresh(db_indisponibilite)

    return db_indisponibilite


@app.delete("/indisponibilite/{indisponibilite_id}/", response_model=None, tags=["Indisponibilite"])
async def delete_indisponibilite(indisponibilite_id: int, database: Session = Depends(get_db)):
    db_indisponibilite = database.query(Indisponibilite).filter(Indisponibilite.id == indisponibilite_id).first()
    if db_indisponibilite is None:
        raise HTTPException(status_code=404, detail="Indisponibilite not found")
    database.delete(db_indisponibilite)
    database.commit()
    return db_indisponibilite



############################################
#   Indisponibilite Method Endpoints
############################################




@app.post("/indisponibilite/{indisponibilite_id}/methods/__init__/", response_model=None, tags=["Indisponibilite Methods"])
async def execute_indisponibilite___init__(
    indisponibilite_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the __init__ method on a Indisponibilite instance.
    """
    # Retrieve the entity from the database
    _indisponibilite_object = database.query(Indisponibilite).filter(Indisponibilite.id == indisponibilite_id).first()
    if _indisponibilite_object is None:
        raise HTTPException(status_code=404, detail="Indisponibilite not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_indisponibilite_object):
            _indisponibilite_object.instances = []
            i1 = IndisponibiliteObj(1, "2026-03-10", "2026-03-12", "Maintenance")
            _indisponibilite_object.instances.append(i1)

        class IndisponibiliteObj:
            def __init__(_indisponibilite_object, idIndisponibilite, dateDebut, dateFin, raison):
                _indisponibilite_object.idIndisponibilite = idIndisponibilite
                _indisponibilite_object.dateDebut = dateDebut
                _indisponibilite_object.dateFin = dateFin
                _indisponibilite_object.raison = raison

        result = await wrapper(_indisponibilite_object)
        # Commit DB
        database.commit()
        database.refresh(_indisponibilite_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "indisponibilite_id": indisponibilite_id,
            "method": "__init__",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")



############################################
#
#   Tarif functions
#
############################################

@app.get("/tarif/", response_model=None, tags=["Tarif"])
def get_all_tarif(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Tarif)
        query = query.options(joinedload(Tarif.element_1))
        tarif_list = query.all()

        # Serialize with relationships included
        result = []
        for tarif_item in tarif_list:
            item_dict = tarif_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if tarif_item.element_1:
                related_obj = tarif_item.element_1
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['element_1'] = related_dict
            else:
                item_dict['element_1'] = None


            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Tarif).all()


@app.get("/tarif/count/", response_model=None, tags=["Tarif"])
def get_count_tarif(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Tarif entities"""
    count = database.query(Tarif).count()
    return {"count": count}


@app.get("/tarif/paginated/", response_model=None, tags=["Tarif"])
def get_paginated_tarif(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Tarif entities"""
    total = database.query(Tarif).count()
    tarif_list = database.query(Tarif).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": tarif_list
    }


@app.get("/tarif/search/", response_model=None, tags=["Tarif"])
def search_tarif(
    database: Session = Depends(get_db)
) -> list:
    """Search Tarif entities by attributes"""
    query = database.query(Tarif)


    results = query.all()
    return results


@app.get("/tarif/{tarif_id}/", response_model=None, tags=["Tarif"])
async def get_tarif(tarif_id: int, database: Session = Depends(get_db)) -> Tarif:
    db_tarif = database.query(Tarif).filter(Tarif.id == tarif_id).first()
    if db_tarif is None:
        raise HTTPException(status_code=404, detail="Tarif not found")

    response_data = {
        "tarif": db_tarif,
}
    return response_data



@app.post("/tarif/", response_model=None, tags=["Tarif"])
async def create_tarif(tarif_data: TarifCreate, database: Session = Depends(get_db)) -> Tarif:

    if tarif_data.element_1 is not None:
        db_element_1 = database.query(Element).filter(Element.id == tarif_data.element_1).first()
        if not db_element_1:
            raise HTTPException(status_code=400, detail="Element not found")
    else:
        raise HTTPException(status_code=400, detail="Element ID is required")

    db_tarif = Tarif(
        idTarif=tarif_data.idTarif,        prixParJour=tarif_data.prixParJour,        saison=tarif_data.saison,        element_1_id=tarif_data.element_1        )

    database.add(db_tarif)
    database.commit()
    database.refresh(db_tarif)




    return db_tarif


@app.post("/tarif/bulk/", response_model=None, tags=["Tarif"])
async def bulk_create_tarif(items: list[TarifCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Tarif entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item
            if not item_data.element_1:
                raise ValueError("Element ID is required")

            db_tarif = Tarif(
                idTarif=item_data.idTarif,                prixParJour=item_data.prixParJour,                saison=item_data.saison,                element_1_id=item_data.element_1            )
            database.add(db_tarif)
            database.flush()  # Get ID without committing
            created_items.append(db_tarif.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Tarif entities"
    }


@app.delete("/tarif/bulk/", response_model=None, tags=["Tarif"])
async def bulk_delete_tarif(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Tarif entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_tarif = database.query(Tarif).filter(Tarif.id == item_id).first()
        if db_tarif:
            database.delete(db_tarif)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Tarif entities"
    }

@app.put("/tarif/{tarif_id}/", response_model=None, tags=["Tarif"])
async def update_tarif(tarif_id: int, tarif_data: TarifCreate, database: Session = Depends(get_db)) -> Tarif:
    db_tarif = database.query(Tarif).filter(Tarif.id == tarif_id).first()
    if db_tarif is None:
        raise HTTPException(status_code=404, detail="Tarif not found")

    setattr(db_tarif, 'idTarif', tarif_data.idTarif)
    setattr(db_tarif, 'prixParJour', tarif_data.prixParJour)
    setattr(db_tarif, 'saison', tarif_data.saison)
    if tarif_data.element_1 is not None:
        db_element_1 = database.query(Element).filter(Element.id == tarif_data.element_1).first()
        if not db_element_1:
            raise HTTPException(status_code=400, detail="Element not found")
        setattr(db_tarif, 'element_1_id', tarif_data.element_1)
    database.commit()
    database.refresh(db_tarif)

    return db_tarif


@app.delete("/tarif/{tarif_id}/", response_model=None, tags=["Tarif"])
async def delete_tarif(tarif_id: int, database: Session = Depends(get_db)):
    db_tarif = database.query(Tarif).filter(Tarif.id == tarif_id).first()
    if db_tarif is None:
        raise HTTPException(status_code=404, detail="Tarif not found")
    database.delete(db_tarif)
    database.commit()
    return db_tarif



############################################
#   Tarif Method Endpoints
############################################




@app.post("/tarif/{tarif_id}/methods/__init__/", response_model=None, tags=["Tarif Methods"])
async def execute_tarif___init__(
    tarif_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the __init__ method on a Tarif instance.
    """
    # Retrieve the entity from the database
    _tarif_object = database.query(Tarif).filter(Tarif.id == tarif_id).first()
    if _tarif_object is None:
        raise HTTPException(status_code=404, detail="Tarif not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_tarif_object):
            _tarif_object.instances = []
            t1 = TarifObj(1, "Hiver", 50.0)
            _tarif_object.instances.append(t1)

        class TarifObj:
            def __init__(_tarif_object, idTarif, saison, prixParJour):
                _tarif_object.idTarif = idTarif
                _tarif_object.saison = saison
                _tarif_object.prixParJour = prixParJour

        result = await wrapper(_tarif_object)
        # Commit DB
        database.commit()
        database.refresh(_tarif_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "tarif_id": tarif_id,
            "method": "__init__",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")



############################################
#
#   Element functions
#
############################################

@app.get("/element/", response_model=None, tags=["Element"])
def get_all_element(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Element)
        query = query.options(joinedload(Element.centre))
        query = query.options(joinedload(Element.reservation_4))
        element_list = query.all()

        # Serialize with relationships included
        result = []
        for element_item in element_list:
            item_dict = element_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if element_item.centre:
                related_obj = element_item.centre
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['centre'] = related_dict
            else:
                item_dict['centre'] = None
            if element_item.reservation_4:
                related_obj = element_item.reservation_4
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['reservation_4'] = related_dict
            else:
                item_dict['reservation_4'] = None

            # Add many-to-many and one-to-many relationship objects (full details)
            indisponibilite_list = database.query(Indisponibilite).filter(Indisponibilite.element_2_id == element_item.id).all()
            item_dict['indisponibilite'] = []
            for indisponibilite_obj in indisponibilite_list:
                indisponibilite_dict = indisponibilite_obj.__dict__.copy()
                indisponibilite_dict.pop('_sa_instance_state', None)
                item_dict['indisponibilite'].append(indisponibilite_dict)
            tarif_list = database.query(Tarif).filter(Tarif.element_1_id == element_item.id).all()
            item_dict['tarif'] = []
            for tarif_obj in tarif_list:
                tarif_dict = tarif_obj.__dict__.copy()
                tarif_dict.pop('_sa_instance_state', None)
                item_dict['tarif'].append(tarif_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Element).all()


@app.get("/element/count/", response_model=None, tags=["Element"])
def get_count_element(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Element entities"""
    count = database.query(Element).count()
    return {"count": count}


@app.get("/element/paginated/", response_model=None, tags=["Element"])
def get_paginated_element(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Element entities"""
    total = database.query(Element).count()
    element_list = database.query(Element).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": element_list
        }

    result = []
    for element_item in element_list:
        indisponibilite_ids = database.query(Indisponibilite.id).filter(Indisponibilite.element_2_id == element_item.id).all()
        tarif_ids = database.query(Tarif.id).filter(Tarif.element_1_id == element_item.id).all()
        item_data = {
            "element": element_item,
            "indisponibilite_ids": [x[0] for x in indisponibilite_ids],            "tarif_ids": [x[0] for x in tarif_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/element/search/", response_model=None, tags=["Element"])
def search_element(
    database: Session = Depends(get_db)
) -> list:
    """Search Element entities by attributes"""
    query = database.query(Element)


    results = query.all()
    return results


@app.get("/element/{element_id}/", response_model=None, tags=["Element"])
async def get_element(element_id: int, database: Session = Depends(get_db)) -> Element:
    db_element = database.query(Element).filter(Element.id == element_id).first()
    if db_element is None:
        raise HTTPException(status_code=404, detail="Element not found")

    indisponibilite_ids = database.query(Indisponibilite.id).filter(Indisponibilite.element_2_id == db_element.id).all()
    tarif_ids = database.query(Tarif.id).filter(Tarif.element_1_id == db_element.id).all()
    response_data = {
        "element": db_element,
        "indisponibilite_ids": [x[0] for x in indisponibilite_ids],        "tarif_ids": [x[0] for x in tarif_ids]}
    return response_data



@app.post("/element/", response_model=None, tags=["Element"])
async def create_element(element_data: ElementCreate, database: Session = Depends(get_db)) -> Element:

    if element_data.centre :
        db_centre = database.query(Centre).filter(Centre.id == element_data.centre).first()
        if not db_centre:
            raise HTTPException(status_code=400, detail="Centre not found")
    if element_data.reservation_4 :
        db_reservation_4 = database.query(Reservation).filter(Reservation.id == element_data.reservation_4).first()
        if not db_reservation_4:
            raise HTTPException(status_code=400, detail="Reservation not found")

    db_element = Element(
        idElement=element_data.idElement,        jourInterdit=element_data.jourInterdit,        nom=element_data.nom,        capaciteMax=element_data.capaciteMax,        dureeMinimale=element_data.dureeMinimale,        centre_id=element_data.centre,        reservation_4_id=element_data.reservation_4        )

    database.add(db_element)
    database.commit()
    database.refresh(db_element)

    if element_data.indisponibilite:
        # Validate that all Indisponibilite IDs exist
        for indisponibilite_id in element_data.indisponibilite:
            db_indisponibilite = database.query(Indisponibilite).filter(Indisponibilite.id == indisponibilite_id).first()
            if not db_indisponibilite:
                raise HTTPException(status_code=400, detail=f"Indisponibilite with id {indisponibilite_id} not found")

        # Update the related entities with the new foreign key
        database.query(Indisponibilite).filter(Indisponibilite.id.in_(element_data.indisponibilite)).update(
            {Indisponibilite.element_2_id: db_element.id}, synchronize_session=False
        )
        database.commit()
    if element_data.tarif:
        # Validate that all Tarif IDs exist
        for tarif_id in element_data.tarif:
            db_tarif = database.query(Tarif).filter(Tarif.id == tarif_id).first()
            if not db_tarif:
                raise HTTPException(status_code=400, detail=f"Tarif with id {tarif_id} not found")

        # Update the related entities with the new foreign key
        database.query(Tarif).filter(Tarif.id.in_(element_data.tarif)).update(
            {Tarif.element_1_id: db_element.id}, synchronize_session=False
        )
        database.commit()



    indisponibilite_ids = database.query(Indisponibilite.id).filter(Indisponibilite.element_2_id == db_element.id).all()
    tarif_ids = database.query(Tarif.id).filter(Tarif.element_1_id == db_element.id).all()
    response_data = {
        "element": db_element,
        "indisponibilite_ids": [x[0] for x in indisponibilite_ids],        "tarif_ids": [x[0] for x in tarif_ids]    }
    return response_data


@app.post("/element/bulk/", response_model=None, tags=["Element"])
async def bulk_create_element(items: list[ElementCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Element entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_element = Element(
                idElement=item_data.idElement,                jourInterdit=item_data.jourInterdit,                nom=item_data.nom,                capaciteMax=item_data.capaciteMax,                dureeMinimale=item_data.dureeMinimale,                centre_id=item_data.centre,                reservation_4_id=item_data.reservation_4            )
            database.add(db_element)
            database.flush()  # Get ID without committing
            created_items.append(db_element.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Element entities"
    }


@app.delete("/element/bulk/", response_model=None, tags=["Element"])
async def bulk_delete_element(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Element entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_element = database.query(Element).filter(Element.id == item_id).first()
        if db_element:
            database.delete(db_element)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Element entities"
    }

@app.put("/element/{element_id}/", response_model=None, tags=["Element"])
async def update_element(element_id: int, element_data: ElementCreate, database: Session = Depends(get_db)) -> Element:
    db_element = database.query(Element).filter(Element.id == element_id).first()
    if db_element is None:
        raise HTTPException(status_code=404, detail="Element not found")

    setattr(db_element, 'idElement', element_data.idElement)
    setattr(db_element, 'jourInterdit', element_data.jourInterdit)
    setattr(db_element, 'nom', element_data.nom)
    setattr(db_element, 'capaciteMax', element_data.capaciteMax)
    setattr(db_element, 'dureeMinimale', element_data.dureeMinimale)
    if element_data.centre is not None:
        db_centre = database.query(Centre).filter(Centre.id == element_data.centre).first()
        if not db_centre:
            raise HTTPException(status_code=400, detail="Centre not found")
        setattr(db_element, 'centre_id', element_data.centre)
    else:
        setattr(db_element, 'centre_id', None)
    if element_data.reservation_4 is not None:
        db_reservation_4 = database.query(Reservation).filter(Reservation.id == element_data.reservation_4).first()
        if not db_reservation_4:
            raise HTTPException(status_code=400, detail="Reservation not found")
        setattr(db_element, 'reservation_4_id', element_data.reservation_4)
    else:
        setattr(db_element, 'reservation_4_id', None)
    if element_data.indisponibilite is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Indisponibilite).filter(Indisponibilite.element_2_id == db_element.id).update(
            {Indisponibilite.element_2_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if element_data.indisponibilite:
            # Validate that all IDs exist
            for indisponibilite_id in element_data.indisponibilite:
                db_indisponibilite = database.query(Indisponibilite).filter(Indisponibilite.id == indisponibilite_id).first()
                if not db_indisponibilite:
                    raise HTTPException(status_code=400, detail=f"Indisponibilite with id {indisponibilite_id} not found")

            # Update the related entities with the new foreign key
            database.query(Indisponibilite).filter(Indisponibilite.id.in_(element_data.indisponibilite)).update(
                {Indisponibilite.element_2_id: db_element.id}, synchronize_session=False
            )
    if element_data.tarif is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Tarif).filter(Tarif.element_1_id == db_element.id).update(
            {Tarif.element_1_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if element_data.tarif:
            # Validate that all IDs exist
            for tarif_id in element_data.tarif:
                db_tarif = database.query(Tarif).filter(Tarif.id == tarif_id).first()
                if not db_tarif:
                    raise HTTPException(status_code=400, detail=f"Tarif with id {tarif_id} not found")

            # Update the related entities with the new foreign key
            database.query(Tarif).filter(Tarif.id.in_(element_data.tarif)).update(
                {Tarif.element_1_id: db_element.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_element)

    indisponibilite_ids = database.query(Indisponibilite.id).filter(Indisponibilite.element_2_id == db_element.id).all()
    tarif_ids = database.query(Tarif.id).filter(Tarif.element_1_id == db_element.id).all()
    response_data = {
        "element": db_element,
        "indisponibilite_ids": [x[0] for x in indisponibilite_ids],        "tarif_ids": [x[0] for x in tarif_ids]    }
    return response_data


@app.delete("/element/{element_id}/", response_model=None, tags=["Element"])
async def delete_element(element_id: int, database: Session = Depends(get_db)):
    db_element = database.query(Element).filter(Element.id == element_id).first()
    if db_element is None:
        raise HTTPException(status_code=404, detail="Element not found")
    database.delete(db_element)
    database.commit()
    return db_element



############################################
#   Element Method Endpoints
############################################




@app.post("/element/{element_id}/methods/valider_creneau/", response_model=None, tags=["Element Methods"])
async def execute_element_valider_creneau(
    element_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the valider_creneau method on a Element instance.

    Parameters:
    - debut: Any    - fin: Any    """
    # Retrieve the entity from the database
    _element_object = database.query(Element).filter(Element.id == element_id).first()
    if _element_object is None:
        raise HTTPException(status_code=404, detail="Element not found")

    # Prepare method parameters
    debut = params.get('debut')
    fin = params.get('fin')

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_element_object):
            duree = (fin - debut).days

            if duree < _element_object.dureeMinimale:
                return False

            if debut.strftime('%A') == _element_object.jourInterdit:
                return False

            return True

        result = await wrapper(_element_object)
        # Commit DB
        database.commit()
        database.refresh(_element_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "element_id": element_id,
            "method": "valider_creneau",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")





@app.post("/element/{element_id}/methods/__init__/", response_model=None, tags=["Element Methods"])
async def execute_element___init__(
    element_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the __init__ method on a Element instance.
    """
    # Retrieve the entity from the database
    _element_object = database.query(Element).filter(Element.id == element_id).first()
    if _element_object is None:
        raise HTTPException(status_code=404, detail="Element not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_element_object):
            _element_object.instances = []
            e1 = ElementObj(1, "Salle Principale", 100, 2, "Dimanche")
            _element_object.instances.append(e1)

        class ElementObj:
            def __init__(_element_object, idElement, nom, capaciteMax, dureeMinimale, jourInterdit):
                _element_object.idElement = idElement
                _element_object.nom = nom
                _element_object.capaciteMax = capaciteMax
                _element_object.dureeMinimale = dureeMinimale
                _element_object.jourInterdit = jourInterdit

        result = await wrapper(_element_object)
        # Commit DB
        database.commit()
        database.refresh(_element_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "element_id": element_id,
            "method": "__init__",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")



############################################
#
#   Evenement functions
#
############################################

@app.get("/evenement/", response_model=None, tags=["Evenement"])
def get_all_evenement(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Evenement)
        query = query.options(joinedload(Evenement.reservation))
        evenement_list = query.all()

        # Serialize with relationships included
        result = []
        for evenement_item in evenement_list:
            item_dict = evenement_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)
            if evenement_item.reservation:
                related_obj = evenement_item.reservation
                related_dict = related_obj.__dict__.copy()
                related_dict.pop('_sa_instance_state', None)
                item_dict['reservation'] = related_dict
            else:
                item_dict['reservation'] = None


            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Evenement).all()


@app.get("/evenement/count/", response_model=None, tags=["Evenement"])
def get_count_evenement(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Evenement entities"""
    count = database.query(Evenement).count()
    return {"count": count}


@app.get("/evenement/paginated/", response_model=None, tags=["Evenement"])
def get_paginated_evenement(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Evenement entities"""
    total = database.query(Evenement).count()
    evenement_list = database.query(Evenement).offset(skip).limit(limit).all()
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": evenement_list
    }


@app.get("/evenement/search/", response_model=None, tags=["Evenement"])
def search_evenement(
    database: Session = Depends(get_db)
) -> list:
    """Search Evenement entities by attributes"""
    query = database.query(Evenement)


    results = query.all()
    return results


@app.get("/evenement/{evenement_id}/", response_model=None, tags=["Evenement"])
async def get_evenement(evenement_id: int, database: Session = Depends(get_db)) -> Evenement:
    db_evenement = database.query(Evenement).filter(Evenement.id == evenement_id).first()
    if db_evenement is None:
        raise HTTPException(status_code=404, detail="Evenement not found")

    response_data = {
        "evenement": db_evenement,
}
    return response_data



@app.post("/evenement/", response_model=None, tags=["Evenement"])
async def create_evenement(evenement_data: EvenementCreate, database: Session = Depends(get_db)) -> Evenement:

    if evenement_data.reservation :
        db_reservation = database.query(Reservation).filter(Reservation.id == evenement_data.reservation).first()
        if not db_reservation:
            raise HTTPException(status_code=400, detail="Reservation not found")

    db_evenement = Evenement(
        nbParticipants=evenement_data.nbParticipants,        nom=evenement_data.nom,        description=evenement_data.description,        idEvenement=evenement_data.idEvenement,        emailReferent=evenement_data.emailReferent,        reservation_id=evenement_data.reservation        )

    database.add(db_evenement)
    database.commit()
    database.refresh(db_evenement)




    return db_evenement


@app.post("/evenement/bulk/", response_model=None, tags=["Evenement"])
async def bulk_create_evenement(items: list[EvenementCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Evenement entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_evenement = Evenement(
                nbParticipants=item_data.nbParticipants,                nom=item_data.nom,                description=item_data.description,                idEvenement=item_data.idEvenement,                emailReferent=item_data.emailReferent,                reservation_id=item_data.reservation            )
            database.add(db_evenement)
            database.flush()  # Get ID without committing
            created_items.append(db_evenement.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Evenement entities"
    }


@app.delete("/evenement/bulk/", response_model=None, tags=["Evenement"])
async def bulk_delete_evenement(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Evenement entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_evenement = database.query(Evenement).filter(Evenement.id == item_id).first()
        if db_evenement:
            database.delete(db_evenement)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Evenement entities"
    }

@app.put("/evenement/{evenement_id}/", response_model=None, tags=["Evenement"])
async def update_evenement(evenement_id: int, evenement_data: EvenementCreate, database: Session = Depends(get_db)) -> Evenement:
    db_evenement = database.query(Evenement).filter(Evenement.id == evenement_id).first()
    if db_evenement is None:
        raise HTTPException(status_code=404, detail="Evenement not found")

    setattr(db_evenement, 'nbParticipants', evenement_data.nbParticipants)
    setattr(db_evenement, 'nom', evenement_data.nom)
    setattr(db_evenement, 'description', evenement_data.description)
    setattr(db_evenement, 'idEvenement', evenement_data.idEvenement)
    setattr(db_evenement, 'emailReferent', evenement_data.emailReferent)
    if evenement_data.reservation is not None:
        db_reservation = database.query(Reservation).filter(Reservation.id == evenement_data.reservation).first()
        if not db_reservation:
            raise HTTPException(status_code=400, detail="Reservation not found")
        setattr(db_evenement, 'reservation_id', evenement_data.reservation)
    else:
        setattr(db_evenement, 'reservation_id', None)
    database.commit()
    database.refresh(db_evenement)

    return db_evenement


@app.delete("/evenement/{evenement_id}/", response_model=None, tags=["Evenement"])
async def delete_evenement(evenement_id: int, database: Session = Depends(get_db)):
    db_evenement = database.query(Evenement).filter(Evenement.id == evenement_id).first()
    if db_evenement is None:
        raise HTTPException(status_code=404, detail="Evenement not found")
    database.delete(db_evenement)
    database.commit()
    return db_evenement



############################################
#   Evenement Method Endpoints
############################################




@app.post("/evenement/{evenement_id}/methods/__init__/", response_model=None, tags=["Evenement Methods"])
async def execute_evenement___init__(
    evenement_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the __init__ method on a Evenement instance.
    """
    # Retrieve the entity from the database
    _evenement_object = database.query(Evenement).filter(Evenement.id == evenement_id).first()
    if _evenement_object is None:
        raise HTTPException(status_code=404, detail="Evenement not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_evenement_object):
            _evenement_object.instances = []
            ev1 = EvenementObj(1, "Conférence IA", "Présentation IA", 30, "contact@centre.fr")
            _evenement_object.instances.append(ev1)

        class EvenementObj:
            def __init__(_evenement_object, idEvenement, nom, description, nbParticipants, emailReferent):
                _evenement_object.idEvenement = idEvenement
                _evenement_object.nom = nom
                _evenement_object.description = description
                _evenement_object.nbParticipants = nbParticipants
                _evenement_object.emailReferent = emailReferent
                _evenement_object.reservation = None
                _evenement_object.element = None

        result = await wrapper(_evenement_object)
        # Commit DB
        database.commit()
        database.refresh(_evenement_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "evenement_id": evenement_id,
            "method": "__init__",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")





@app.post("/evenement/{evenement_id}/methods/verifier_logistique/", response_model=None, tags=["Evenement Methods"])
async def execute_evenement_verifier_logistique(
    evenement_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the verifier_logistique method on a Evenement instance.
    """
    # Retrieve the entity from the database
    _evenement_object = database.query(Evenement).filter(Evenement.id == evenement_id).first()
    if _evenement_object is None:
        raise HTTPException(status_code=404, detail="Evenement not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_evenement_object):
            if _evenement_object.reservation and _evenement_object.reservation.element:
                return _evenement_object.nbParticipants <= _evenement_object.reservation.element.capaciteMax
            return False

        result = await wrapper(_evenement_object)
        # Commit DB
        database.commit()
        database.refresh(_evenement_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "evenement_id": evenement_id,
            "method": "verifier_logistique",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")



############################################
#
#   Centre functions
#
############################################

@app.get("/centre/", response_model=None, tags=["Centre"])
def get_all_centre(detailed: bool = False, database: Session = Depends(get_db)) -> list:
    from sqlalchemy.orm import joinedload

    # Use detailed=true to get entities with eagerly loaded relationships (for tables with lookup columns)
    if detailed:
        # Eagerly load all relationships to avoid N+1 queries
        query = database.query(Centre)
        centre_list = query.all()

        # Serialize with relationships included
        result = []
        for centre_item in centre_list:
            item_dict = centre_item.__dict__.copy()
            item_dict.pop('_sa_instance_state', None)

            # Add many-to-one relationships (foreign keys for lookup columns)

            # Add many-to-many and one-to-many relationship objects (full details)
            element_list = database.query(Element).filter(Element.centre_id == centre_item.id).all()
            item_dict['element'] = []
            for element_obj in element_list:
                element_dict = element_obj.__dict__.copy()
                element_dict.pop('_sa_instance_state', None)
                item_dict['element'].append(element_dict)
            reservation_list = database.query(Reservation).filter(Reservation.centre_1_id == centre_item.id).all()
            item_dict['reservation_3'] = []
            for reservation_obj in reservation_list:
                reservation_dict = reservation_obj.__dict__.copy()
                reservation_dict.pop('_sa_instance_state', None)
                item_dict['reservation_3'].append(reservation_dict)

            result.append(item_dict)
        return result
    else:
        # Default: return flat entities (faster for charts/widgets without lookup columns)
        return database.query(Centre).all()


@app.get("/centre/count/", response_model=None, tags=["Centre"])
def get_count_centre(database: Session = Depends(get_db)) -> dict:
    """Get the total count of Centre entities"""
    count = database.query(Centre).count()
    return {"count": count}


@app.get("/centre/paginated/", response_model=None, tags=["Centre"])
def get_paginated_centre(skip: int = 0, limit: int = 100, detailed: bool = False, database: Session = Depends(get_db)) -> dict:
    """Get paginated list of Centre entities"""
    total = database.query(Centre).count()
    centre_list = database.query(Centre).offset(skip).limit(limit).all()
    # By default, return flat entities (for charts/widgets)
    # Use detailed=true to get entities with relationships
    if not detailed:
        return {
            "total": total,
            "skip": skip,
            "limit": limit,
            "data": centre_list
        }

    result = []
    for centre_item in centre_list:
        element_ids = database.query(Element.id).filter(Element.centre_id == centre_item.id).all()
        reservation_3_ids = database.query(Reservation.id).filter(Reservation.centre_1_id == centre_item.id).all()
        item_data = {
            "centre": centre_item,
            "element_ids": [x[0] for x in element_ids],            "reservation_3_ids": [x[0] for x in reservation_3_ids]        }
        result.append(item_data)
    return {
        "total": total,
        "skip": skip,
        "limit": limit,
        "data": result
    }


@app.get("/centre/search/", response_model=None, tags=["Centre"])
def search_centre(
    database: Session = Depends(get_db)
) -> list:
    """Search Centre entities by attributes"""
    query = database.query(Centre)


    results = query.all()
    return results


@app.get("/centre/{centre_id}/", response_model=None, tags=["Centre"])
async def get_centre(centre_id: int, database: Session = Depends(get_db)) -> Centre:
    db_centre = database.query(Centre).filter(Centre.id == centre_id).first()
    if db_centre is None:
        raise HTTPException(status_code=404, detail="Centre not found")

    element_ids = database.query(Element.id).filter(Element.centre_id == db_centre.id).all()
    reservation_3_ids = database.query(Reservation.id).filter(Reservation.centre_1_id == db_centre.id).all()
    response_data = {
        "centre": db_centre,
        "element_ids": [x[0] for x in element_ids],        "reservation_3_ids": [x[0] for x in reservation_3_ids]}
    return response_data



@app.post("/centre/", response_model=None, tags=["Centre"])
async def create_centre(centre_data: CentreCreate, database: Session = Depends(get_db)) -> Centre:


    db_centre = Centre(
        nom=centre_data.nom,        adresse=centre_data.adresse,        idCentre=centre_data.idCentre        )

    database.add(db_centre)
    database.commit()
    database.refresh(db_centre)

    if centre_data.element:
        # Validate that all Element IDs exist
        for element_id in centre_data.element:
            db_element = database.query(Element).filter(Element.id == element_id).first()
            if not db_element:
                raise HTTPException(status_code=400, detail=f"Element with id {element_id} not found")

        # Update the related entities with the new foreign key
        database.query(Element).filter(Element.id.in_(centre_data.element)).update(
            {Element.centre_id: db_centre.id}, synchronize_session=False
        )
        database.commit()
    if centre_data.reservation_3:
        # Validate that all Reservation IDs exist
        for reservation_id in centre_data.reservation_3:
            db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
            if not db_reservation:
                raise HTTPException(status_code=400, detail=f"Reservation with id {reservation_id} not found")

        # Update the related entities with the new foreign key
        database.query(Reservation).filter(Reservation.id.in_(centre_data.reservation_3)).update(
            {Reservation.centre_1_id: db_centre.id}, synchronize_session=False
        )
        database.commit()



    element_ids = database.query(Element.id).filter(Element.centre_id == db_centre.id).all()
    reservation_3_ids = database.query(Reservation.id).filter(Reservation.centre_1_id == db_centre.id).all()
    response_data = {
        "centre": db_centre,
        "element_ids": [x[0] for x in element_ids],        "reservation_3_ids": [x[0] for x in reservation_3_ids]    }
    return response_data


@app.post("/centre/bulk/", response_model=None, tags=["Centre"])
async def bulk_create_centre(items: list[CentreCreate], database: Session = Depends(get_db)) -> dict:
    """Create multiple Centre entities at once"""
    created_items = []
    errors = []

    for idx, item_data in enumerate(items):
        try:
            # Basic validation for each item

            db_centre = Centre(
                nom=item_data.nom,                adresse=item_data.adresse,                idCentre=item_data.idCentre            )
            database.add(db_centre)
            database.flush()  # Get ID without committing
            created_items.append(db_centre.id)
        except Exception as e:
            errors.append({"index": idx, "error": str(e)})

    if errors:
        database.rollback()
        raise HTTPException(status_code=400, detail={"message": "Bulk creation failed", "errors": errors})

    database.commit()
    return {
        "created_count": len(created_items),
        "created_ids": created_items,
        "message": f"Successfully created {len(created_items)} Centre entities"
    }


@app.delete("/centre/bulk/", response_model=None, tags=["Centre"])
async def bulk_delete_centre(ids: list[int], database: Session = Depends(get_db)) -> dict:
    """Delete multiple Centre entities at once"""
    deleted_count = 0
    not_found = []

    for item_id in ids:
        db_centre = database.query(Centre).filter(Centre.id == item_id).first()
        if db_centre:
            database.delete(db_centre)
            deleted_count += 1
        else:
            not_found.append(item_id)

    database.commit()

    return {
        "deleted_count": deleted_count,
        "not_found": not_found,
        "message": f"Successfully deleted {deleted_count} Centre entities"
    }

@app.put("/centre/{centre_id}/", response_model=None, tags=["Centre"])
async def update_centre(centre_id: int, centre_data: CentreCreate, database: Session = Depends(get_db)) -> Centre:
    db_centre = database.query(Centre).filter(Centre.id == centre_id).first()
    if db_centre is None:
        raise HTTPException(status_code=404, detail="Centre not found")

    setattr(db_centre, 'nom', centre_data.nom)
    setattr(db_centre, 'adresse', centre_data.adresse)
    setattr(db_centre, 'idCentre', centre_data.idCentre)
    if centre_data.element is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Element).filter(Element.centre_id == db_centre.id).update(
            {Element.centre_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if centre_data.element:
            # Validate that all IDs exist
            for element_id in centre_data.element:
                db_element = database.query(Element).filter(Element.id == element_id).first()
                if not db_element:
                    raise HTTPException(status_code=400, detail=f"Element with id {element_id} not found")

            # Update the related entities with the new foreign key
            database.query(Element).filter(Element.id.in_(centre_data.element)).update(
                {Element.centre_id: db_centre.id}, synchronize_session=False
            )
    if centre_data.reservation_3 is not None:
        # Clear all existing relationships (set foreign key to NULL)
        database.query(Reservation).filter(Reservation.centre_1_id == db_centre.id).update(
            {Reservation.centre_1_id: None}, synchronize_session=False
        )

        # Set new relationships if list is not empty
        if centre_data.reservation_3:
            # Validate that all IDs exist
            for reservation_id in centre_data.reservation_3:
                db_reservation = database.query(Reservation).filter(Reservation.id == reservation_id).first()
                if not db_reservation:
                    raise HTTPException(status_code=400, detail=f"Reservation with id {reservation_id} not found")

            # Update the related entities with the new foreign key
            database.query(Reservation).filter(Reservation.id.in_(centre_data.reservation_3)).update(
                {Reservation.centre_1_id: db_centre.id}, synchronize_session=False
            )
    database.commit()
    database.refresh(db_centre)

    element_ids = database.query(Element.id).filter(Element.centre_id == db_centre.id).all()
    reservation_3_ids = database.query(Reservation.id).filter(Reservation.centre_1_id == db_centre.id).all()
    response_data = {
        "centre": db_centre,
        "element_ids": [x[0] for x in element_ids],        "reservation_3_ids": [x[0] for x in reservation_3_ids]    }
    return response_data


@app.delete("/centre/{centre_id}/", response_model=None, tags=["Centre"])
async def delete_centre(centre_id: int, database: Session = Depends(get_db)):
    db_centre = database.query(Centre).filter(Centre.id == centre_id).first()
    if db_centre is None:
        raise HTTPException(status_code=404, detail="Centre not found")
    database.delete(db_centre)
    database.commit()
    return db_centre



############################################
#   Centre Method Endpoints
############################################




@app.post("/centre/{centre_id}/methods/__init__/", response_model=None, tags=["Centre Methods"])
async def execute_centre___init__(
    centre_id: int,
    params: dict = Body(default=None, embed=True),
    database: Session = Depends(get_db)
):
    """
    Execute the __init__ method on a Centre instance.
    """
    # Retrieve the entity from the database
    _centre_object = database.query(Centre).filter(Centre.id == centre_id).first()
    if _centre_object is None:
        raise HTTPException(status_code=404, detail="Centre not found")

    # Prepare method parameters

    # Execute the method
    try:
        # Capture stdout to include print outputs in the response
        import io
        import sys
        captured_output = io.StringIO()
        sys.stdout = captured_output

        async def wrapper(_centre_object):
            _centre_object.instances = []
            c1 = CentreObj(1, "Centre Ville", "1 rue du Parc")
            _centre_object.instances.append(c1)

        class CentreObj:
            def __init__(_centre_object, idCentre, nom, adresse):
                _centre_object.idCentre = idCentre
                _centre_object.nom = nom
                _centre_object.adresse = adresse

        result = await wrapper(_centre_object)
        # Commit DB
        database.commit()
        database.refresh(_centre_object)

        # Restore stdout
        sys.stdout = sys.__stdout__
        output = captured_output.getvalue()

        return {
            "centre_id": centre_id,
            "method": "__init__",
            "status": "executed",
            "result": str(result) if result is not None else None,
            "output": output if output else None
        }
    except Exception as e:
        sys.stdout = sys.__stdout__
        raise HTTPException(status_code=500, detail=f"Method execution failed: {str(e)}")





############################################
# Maintaining the server
############################################
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)



