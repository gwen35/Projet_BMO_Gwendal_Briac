from datetime import datetime, date, time
from typing import Any, List, Optional, Union, Set
from enum import Enum
from pydantic import BaseModel, field_validator


############################################
# Enumerations are defined here
############################################

############################################
# Classes are defined here
############################################
class PrestationCreate(BaseModel):
    nom: str
    type: str
    capaciteMax: int
    idPrestation: int
    reservation_2: List[int] =[]  # N:M Relationship


class MaterielCreate(BaseModel):
    quantiteDisponible: int
    idMateriel: int
    nom: str
    reservation_1: List[int]=[]  # N:M Relationship


class ReservationCreate(BaseModel):
    dateDebut: date
    montantTotal: float
    idReservation: int
    statut: str
    dateFin: date
    prestation: List[int] = []  # N:M Relationship
    materiel: List[int] = []  # N:M Relationship
    element_3: Optional[List[int]] = None  # 1:N Relationship
    evenement: Optional[int] = None  # 1:1 Relationship (optional)
    centre_1: Optional[int] = None  # N:1 Relationship (mandatory)


class IndisponibiliteCreate(BaseModel):
    idIndisponbilite: int
    raison: str
    dateFin: date
    dateDebut: date
    element_2: int  # N:1 Relationship (mandatory)


class TarifCreate(BaseModel):
    idTarif: int
    prixParJour: float
    saison: str
    element_1: int  # N:1 Relationship (mandatory)


class ElementCreate(BaseModel):
    idElement: int
    jourInterdit: str
    nom: str
    capaciteMax: int
    dureeMinimale: int
    indisponibilite: Optional[List[int]] = None  # 1:N Relationship
    centre: Optional[int] = None  # N:1 Relationship (optional)
    tarif: Optional[List[int]] = None  # 1:N Relationship
    reservation_4: Optional[int] = None  # N:1 Relationship (optional)


class EvenementCreate(BaseModel):
    nbParticipants: int
    nom: str
    description: str
    idEvenement: int
    emailReferent: str
    reservation: Optional[int] = None  # 1:1 Relationship (optional)


class CentreCreate(BaseModel):
    nom: str
    adresse: str
    idCentre: int
    element: Optional[List[int]] = None  # 1:N Relationship
    reservation_3: Optional[List[int]] = None  # 1:N Relationship


