import React, { CSSProperties } from "react";

interface Props {
  id: string;
  "metric-title"?: string;
  "value-color"?: string;
  "value-size"?: number;
  "show-trend"?: boolean;
  "positive-color"?: string;
  "negative-color"?: string;
  format?: "number" | "currency" | "percentage" | "time";
  value?: number;
  trend?: number;
  data_binding?: {
    entity?: string;
    endpoint?: string;
    data_field?: string;
    aggregation?: string;
  };
  styles?: CSSProperties;
}

// Format value based on format type
const formatValue = (value: number, format: string): string => {
  switch (format) {
    case "currency":
      return `$${value.toLocaleString("en-US", {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      })}`;
    case "percentage":
      return `${value.toFixed(2)}%`;
    case "time":
      const hours = Math.floor(value / 60);
      const minutes = value % 60;
      return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
    case "number":
    default:
      return value.toLocaleString("en-US", {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      });
  }
};


export const MetricCardComponent: React.FC<Props> = ({
  id,
  "metric-title": metricTitle = "Metric Title",
  "value-color": valueColor = "#2c3e50",
  "value-size": valueSize = 32,
  "show-trend": showTrend = true,
  "positive-color": positiveColor = "#27ae60",
  "negative-color": negativeColor = "#e74c3c",
  format = "number",
  value = 0,
  trend = 0,
  data_binding,
  styles,
}) => {
    // TODO: Uncomment when backend aggregation is ready
  // const displayValue = data_binding?.entity
  //   ? `${data_binding.aggregation?.toUpperCase() || "SUM"}(${
  //       data_binding.data_field || "field"
  //     })`
  //   : formatValue(value, format);
  
  // For now, just show formatted placeholder value
  const displayValue = formatValue(value, format);

  const trendColor = trend >= 0 ? positiveColor : negativeColor;

  const containerStyle: CSSProperties = {
    background: "white",
    padding: "25px",
    borderRadius: "10px",
    boxShadow: "0 4px 6px rgba(0,0,0,0.1)",
    fontFamily: "Arial, sans-serif",
    minHeight: "140px",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
    ...styles,
  };

  return (
    <div id={id} style={containerStyle}>
      {/* Metric Title */}
      <div
        style={{
          color: "#666",
          fontSize: "14px",
          marginBottom: "8px",
          fontWeight: "500",
        }}
      >
        {metricTitle}
      </div>

      {/* Metric Value */}
      <div
        style={{
          fontSize: `${valueSize}px`,
          fontWeight: "bold",
          color: valueColor,
          marginBottom: "8px",
          wordBreak: "break-word",
        }}
      >
        {displayValue}
      </div>

      {/* Trend Indicator (optional) */}
      {showTrend && (
        <div
          style={{
            color: trendColor,
            fontSize: "12px",
            marginTop: "8px",
            fontWeight: "500",
          }}
        >
          {/* TODO: Uncomment when backend aggregation is ready */}
          {/* {hasDataBinding
            ? "📊 Data bound to " + (data_binding.entity || "entity")
            : formatTrend(trend)} */}
          {/* {formatTrend(trend)} */}
          Latest value
        </div>
      )}

      {/* TODO: Uncomment when backend aggregation is ready */}
      {/* Data Binding Info (only in development) */}
      {/* {hasDataBinding && process.env.NODE_ENV === "development" && (
        <div
          style={{
            marginTop: "10px",
            padding: "8px",
            background: "#f0f0f0",
            borderRadius: "4px",
            fontSize: "11px",
            color: "#666",
            fontFamily: "monospace",
          }}
        >
          <div>📦 Entity: {data_binding.entity}</div>
          <div>📊 Field: {data_binding.data_field || "none"}</div>
          <div>🧮 Agg: {data_binding.aggregation || "none"}</div>
        </div>
      )} */}
    </div>
  );
};