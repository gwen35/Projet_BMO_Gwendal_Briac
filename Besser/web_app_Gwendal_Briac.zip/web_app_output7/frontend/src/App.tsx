import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { TableProvider } from "./contexts/TableContext";
import Centre from "./pages/Centre";
import Evenement from "./pages/Evenement";
import Element from "./pages/Element";
import Tarif from "./pages/Tarif";
import Indisponibilite from "./pages/Indisponibilite";
import Reservation from "./pages/Reservation";
import Materiel from "./pages/Materiel";
import Prestation from "./pages/Prestation";

function App() {
  return (
    <TableProvider>
      <div className="app-container">
        <main className="app-main">
          <Routes>
            <Route path="/centre" element={<Centre />} />
            <Route path="/evenement" element={<Evenement />} />
            <Route path="/element" element={<Element />} />
            <Route path="/tarif" element={<Tarif />} />
            <Route path="/indisponibilite" element={<Indisponibilite />} />
            <Route path="/reservation" element={<Reservation />} />
            <Route path="/materiel" element={<Materiel />} />
            <Route path="/prestation" element={<Prestation />} />
            <Route path="/" element={<Navigate to="/centre" replace />} />
            <Route path="*" element={<Navigate to="/centre" replace />} />
          </Routes>
        </main>
      </div>
    </TableProvider>
  );
}
export default App;
